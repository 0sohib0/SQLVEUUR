from dataclasses import dataclass, field, asdict
from typing import List
import sqlite3
import re
import json

@dataclass
class Column:
    name: str
    data_type: str
    is_pk: bool = False

@dataclass
class Relationship:
    from_table: str
    to_table: str
    rel_type: str = "1-N"

@dataclass
class Table:
    name: str
    x: float = 0.0
    y: float = 0.0
    columns: List[Column] = field(default_factory=list)

class SchemaModel:
    def __init__(self):
        self.tables = {}
        self.relationships = []
        self.db_con = sqlite3.connect(":memory:") 
        self.db_cur = self.db_con.cursor()

    def clear(self):
        self.tables = {}
        self.relationships = []
        self.db_con.close()
        self.db_con = sqlite3.connect(":memory:")
        self.db_cur = self.db_con.cursor()

    def to_dict(self):
        # تحويل البيانات إلى قاموس للحفظ
        return {
            "tables": {name: asdict(t) for name, t in self.tables.items()},
            "relationships": [asdict(r) for r in self.relationships]
        }

    def from_dict(self, data):
        # استعادة البيانات من القاموس
        self.clear()
        for t_name, t_data in data.get("tables", {}).items():
            cols = [Column(**c) for c in t_data["columns"]]
            self.tables[t_name] = Table(name=t_name, x=t_data["x"], y=t_data["y"], columns=cols)
        
        for r_data in data.get("relationships", []):
            self.relationships.append(Relationship(**r_data))

    def add_table(self, name, pk_name="id", pk_type="INTEGER", x=0, y=0):
        if name in self.tables: raise ValueError(f"Table '{name}' exists!")
        new_table = Table(name=name, x=x, y=y)
        new_table.columns.append(Column(pk_name, pk_type, True))
        self.tables[name] = new_table
        return new_table

    def parse_create_table_sql(self, sql_query):
        clean_sql = sql_query.strip()
        pattern = r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)\s*\((.+)\)"
        match = re.search(pattern, clean_sql, re.IGNORECASE | re.DOTALL)
        if match:
            tbl_name = match.group(1); cols_str = match.group(2)
            if tbl_name in self.tables: return tbl_name 
            import random
            new_tbl = Table(name=tbl_name, x=50+random.randint(0,50), y=50+random.randint(0,50))
            col_parts = [c.strip() for c in cols_str.split(',')]
            for part in col_parts:
                part = part.strip()
                if not part or any(kw in part.upper() for kw in ["FOREIGN KEY", "CONSTRAINT", "PRIMARY KEY ("]): continue
                tokens = part.split()
                if not tokens: continue
                c_name = tokens[0]; c_type = tokens[1] if len(tokens)>1 else "TEXT"
                is_pk = "PRIMARY KEY" in part.upper()
                new_tbl.columns.append(Column(c_name, c_type, is_pk))
            self.tables[tbl_name] = new_tbl
            return tbl_name
        return None

    def rename_table(self, old, new):
        if old not in self.tables: return
        self.tables[new] = self.tables.pop(old); self.tables[new].name = new
        for r in self.relationships:
            if r.from_table == old: r.from_table = new
            if r.to_table == old: r.to_table = new

    def delete_table(self, name):
        if name in self.tables:
            del self.tables[name]
            self.relationships = [r for r in self.relationships if r.from_table != name and r.to_table != name]

    def add_column(self, t_name, c_name, c_type, is_pk=False):
        if t_name in self.tables: self.tables[t_name].columns.append(Column(c_name, c_type, is_pk))

    def delete_column(self, t_name, c_name):
        if t_name in self.tables: self.tables[t_name].columns = [c for c in self.tables[t_name].columns if c.name != c_name]

    def add_relationship(self, f, t, r_type="1-N"):
        for r in self.relationships:
            if r.from_table == f and r.to_table == t: return
        self.relationships.append(Relationship(f, t, r_type))
        if r_type == "1-N": self.add_column(f, f"{t.lower()}_id", "INTEGER", False)

    def delete_relationship(self, f, t):
        rel = next((r for r in self.relationships if r.from_table == f and r.to_table == t), None)
        if rel:
            self.relationships.remove(rel)
            if rel.rel_type == "1-N": self.delete_column(f, f"{t.lower()}_id")

    def generate_sql(self):
        sql = []
        for t in self.tables.values():
            cols = [f"{c.name} {c.data_type}" + (" PRIMARY KEY" if c.is_pk else "") for c in t.columns]
            for r in self.relationships:
                if r.from_table == t.name:
                    fk = f"{r.to_table.lower()}_id"
                    if any(c.name == fk for c in t.columns): cols.append(f"FOREIGN KEY({fk}) REFERENCES {r.to_table}(id)")
            sql.append(f"CREATE TABLE IF NOT EXISTS {t.name} (\n  " + ',\n  '.join(cols) + "\n);")
        return "\n\n".join(sql)

    def execute_query(self, query):
        try:
            full_schema = self.generate_sql()
            if full_schema.strip(): 
                try: self.db_cur.executescript(full_schema)
                except: pass
            self.db_cur.execute(query)
            if query.strip().upper().startswith("SELECT"): return [d[0] for d in self.db_cur.description], self.db_cur.fetchall()
            else: self.db_con.commit(); return ["Info"], [("Success",)]
        except Exception as e: return ["Error"], [(str(e),)]
