from dataclasses import dataclass, field
from typing import List
import sqlite3
import re

@dataclass
class Column:
    name: str
    data_type: str
    is_pk: bool = False

@dataclass
class Relationship:
    from_table: str
    to_table: str
    rel_type: str = "1-N"

@dataclass
class Table:
    name: str
    x: float = 0.0
    y: float = 0.0
    columns: List[Column] = field(default_factory=list)

class SchemaModel:
    def __init__(self):
        self.tables = {}
        self.relationships = []
        # In-memory DB for data storage
        self.db_con = sqlite3.connect(":memory:") 
        self.db_cur = self.db_con.cursor()

    def add_table(self, name, pk_name="id", pk_type="INTEGER", x=0, y=0):
        if name in self.tables:
            raise ValueError(f"Table '{name}' already exists!")
        new_table = Table(name=name, x=x, y=y)
        new_table.columns.append(Column(pk_name, pk_type, True))
        self.tables[name] = new_table
        return new_table

    # --- NEW: Parse SQL to create tables visually ---
    def parse_create_table_sql(self, sql_query):
        # Regex to find 'CREATE TABLE name (columns)'
        pattern = r"CREATE\s+TABLE\s+(\w+)\s*\((.+)\)"
        match = re.search(pattern, sql_query, re.IGNORECASE | re.DOTALL)
        
        if match:
            tbl_name = match.group(1)
            cols_str = match.group(2)
            
            if tbl_name in self.tables:
                raise ValueError(f"Table {tbl_name} already exists in visual model.")

            # Create Table Object
            new_tbl = Table(name=tbl_name, x=50, y=50) # Default pos
            
            # Parse Columns
            # Very basic parser: splits by comma, looks for PRIMARY KEY
            col_parts = [c.strip() for c in cols_str.split(',')]
            for part in col_parts:
                part = part.strip()
                if not part: continue
                if "FOREIGN KEY" in part.upper(): continue # Skip FK definition lines for visual simplicity here
                
                # Split definition: "id INTEGER PRIMARY KEY" -> ["id", "INTEGER", "PRIMARY", "KEY"]
                tokens = part.split()
                if not tokens: continue
                
                c_name = tokens[0]
                c_type = tokens[1] if len(tokens) > 1 else "TEXT"
                is_pk = "PRIMARY KEY" in part.upper()
                
                new_tbl.columns.append(Column(c_name, c_type, is_pk))
            
            self.tables[tbl_name] = new_tbl
            return tbl_name
        return None

    def rename_table(self, old_name, new_name):
        if old_name not in self.tables: return
        if new_name in self.tables: raise ValueError(f"Table '{new_name}' already exists!")
        self.tables[new_name] = self.tables.pop(old_name)
        self.tables[new_name].name = new_name
        for r in self.relationships:
            if r.from_table == old_name: r.from_table = new_name
            if r.to_table == old_name: r.to_table = new_name

    def delete_table(self, name):
        if name in self.tables:
            del self.tables[name]
            self.relationships = [r for r in self.relationships if r.from_table != name and r.to_table != name]

    def add_column(self, table_name, col_name, col_type, is_pk=False):
        if table_name in self.tables:
            for col in self.tables[table_name].columns:
                if col.name == col_name: return 
            self.tables[table_name].columns.append(Column(col_name, col_type, is_pk))

    def delete_column(self, table_name, col_name):
        if table_name in self.tables:
            tbl = self.tables[table_name]
            tbl.columns = [c for c in tbl.columns if c.name != col_name]

    def add_relationship(self, from_tbl, to_tbl, rel_type="1-N"):
        for r in self.relationships:
            if r.from_table == from_tbl and r.to_table == to_tbl: return
        self.relationships.append(Relationship(from_tbl, to_tbl, rel_type))
        if rel_type == "1-N":
            fk_name = f"{to_tbl.lower()}_id"
            self.add_column(from_tbl, fk_name, "INTEGER", False)

    def delete_relationship(self, from_tbl, to_tbl):
        rel_to_remove = None
        for r in self.relationships:
            if r.from_table == from_tbl and r.to_table == to_tbl:
                rel_to_remove = r
                break
        if rel_to_remove:
            self.relationships.remove(rel_to_remove)
            if rel_to_remove.rel_type == "1-N":
                fk_name = f"{to_tbl.lower()}_id"
                self.delete_column(from_tbl, fk_name)

    def generate_sql(self):
        sql_stmts = []
        for table in self.tables.values():
            cols_sql = []
            for col in table.columns:
                stmt = f"{col.name} {col.data_type}"
                if col.is_pk: stmt += " PRIMARY KEY"
                cols_sql.append(stmt)
            for rel in self.relationships:
                if rel.from_table == table.name:
                    fk_col = f"{rel.to_table.lower()}_id"
                    if any(c.name == fk_col for c in table.columns):
                        cols_sql.append(f"FOREIGN KEY({fk_col}) REFERENCES {rel.to_table}(id)")
            sql_stmts.append(f"CREATE TABLE IF NOT EXISTS {table.name} (\n  " + ',\n  '.join(cols_sql) + "\n);")
        return "\n\n".join(sql_stmts)

    def execute_query(self, query):
        try:
            # 1. Ensure Schema exists in DB
            full_schema = self.generate_sql()
            if full_schema.strip(): 
                # We use executescript but catch error if table exists (handled by IF NOT EXISTS)
                try: self.db_cur.executescript(full_schema)
                except: pass

            # 2. Execute User Query
            self.db_cur.execute(query)
            
            if query.strip().upper().startswith("SELECT"):
                columns = [d[0] for d in self.db_cur.description]
                rows = self.db_cur.fetchall()
                # self.db_con.commit() # Not needed for select
                return columns, rows
            else:
                self.db_con.commit()
                return ["Info"], [("Query Executed Successfully",)]
        except Exception as e:
            return ["Error"], [(str(e),)]
