from PySide6.QtWidgets import (QGraphicsScene, QGraphicsView, QGraphicsRectItem, 
                                 QGraphicsTextItem, QGraphicsItem, QMenu, QGraphicsLineItem, QGraphicsDropShadowEffect)
from PySide6.QtCore import Qt, QPointF, Signal, QObject, QLineF, QRectF
from PySide6.QtGui import QBrush, QPen, QColor, QFont, QPainter, QLinearGradient, QPainterPath

class Communicate(QObject):
    request_edit_table = Signal(str)
    request_delete_table = Signal(str)
    request_delete_rel = Signal(str, str)
    request_insert_data = Signal(str) # NEW

class ConnectorLine(QGraphicsLineItem):
    def __init__(self, start_item, end_item, rel_type, comms):
        super().__init__()
        self.start_item = start_item
        self.end_item = end_item
        self.rel_type = rel_type
        self.comms = comms
        self.setZValue(-2) # Way behind
        self.setFlag(QGraphicsItem.ItemIsSelectable)
        
        # Style Line
        pen = QPen(QColor("#a0a0a0"), 2)
        pen.setStyle(Qt.DashLine) # Modern Look
        self.setPen(pen)

        self.start_label = QGraphicsTextItem("", self)
        self.end_label = QGraphicsTextItem("", self)
        self.setup_labels()
        self.update_position()

    def setup_labels(self):
        font = QFont("Segoe UI", 10, QFont.Bold)
        self.start_label.setFont(font)
        self.end_label.setFont(font)
        self.start_label.setDefaultTextColor(QColor("#ff5555")) # Bright Red
        self.end_label.setDefaultTextColor(QColor("#ff5555"))

        if self.rel_type == "1-N":
            self.start_label.setPlainText("N")
            self.end_label.setPlainText("1")
        elif self.rel_type == "N-N": 
            self.start_label.setPlainText("N")
            self.end_label.setPlainText("N") 

    def update_position(self):
        start_pos = self.start_item.scenePos() + QPointF(self.start_item.boundingRect().width()/2, self.start_item.boundingRect().height()/2)
        end_pos = self.end_item.scenePos() + QPointF(self.end_item.boundingRect().width()/2, self.end_item.boundingRect().height()/2)
        line = QLineF(start_pos, end_pos)
        self.setLine(line)
        self.start_label.setPos(line.pointAt(0.15))
        self.end_label.setPos(line.pointAt(0.85))

    def contextMenuEvent(self, event):
        menu = QMenu()
        menu.setStyleSheet("QMenu { background-color: #333; color: white; } QMenu::item:selected { background-color: #555; }")
        del_action = menu.addAction("❌ Delete Connection")
        selected = menu.exec(event.screenPos())
        if selected == del_action:
            self.comms.request_delete_rel.emit(self.start_item.table_name, self.end_item.table_name)

class TableItem(QGraphicsItem):
    def __init__(self, table_name, x, y, comms):
        super().__init__()
        self.setPos(x, y)
        self.comms = comms
        self.table_name = table_name
        self.columns_list = []
        self.lines = []
        
        # Enable interaction
        self.setFlags(QGraphicsItem.ItemIsMovable | QGraphicsItem.ItemIsSelectable | QGraphicsItem.ItemSendsGeometryChanges)
        
        # Dimensions
        self.width = 180
        self.header_height = 35
        self.row_height = 20
        self.height = 100 # Initial

    def boundingRect(self):
        return QRectF(0, 0, self.width, self.height)

    def paint(self, painter, option, widget):
        # 1. Shadow effect is handled by GraphicsEffect externally or simple offset here
        # Let's draw the Main Body (White/Light Grey)
        path = QPainterPath()
        path.addRoundedRect(self.boundingRect(), 10, 10)
        
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillPath(path, QBrush(QColor("#2d2d2d"))) # Dark Body
        
        # Border
        painter.setPen(QPen(QColor("#444"), 1))
        painter.drawPath(path)

        # 2. Header (Gradient)
        header_path = QPainterPath()
        header_path.addRoundedRect(0, 0, self.width, self.header_height, 10, 10)
        
        # Clip bottom to make it straight
        painter.save()
        painter.setClipRect(0, 0, self.width, self.header_height)
        
        grad = QLinearGradient(0, 0, self.width, self.header_height)
        grad.setColorAt(0, QColor("#6a11cb")) # Deep Purple
        grad.setColorAt(1, QColor("#2575fc")) # Blue
        painter.fillPath(header_path, QBrush(grad))
        painter.restore()

        # 3. Table Title
        painter.setPen(Qt.white)
        painter.setFont(QFont("Segoe UI", 11, QFont.Bold))
        painter.drawText(QRectF(0, 0, self.width, self.header_height), Qt.AlignCenter, self.table_name)

        # 4. Columns
        y_offset = self.header_height + 20
        painter.setFont(QFont("Consolas", 9))
        
        for col in self.columns_list:
            # Icon
            icon = "🔑" if col.is_pk else "🔹"
            color = QColor("#ffeb3b") if col.is_pk else QColor("#a0a0a0")
            
            painter.setPen(color)
            painter.drawText(10, y_offset, icon)
            
            # Name
            painter.setPen(QColor("#e0e0e0"))
            painter.drawText(35, y_offset, col.name)
            
            # Type (Right Aligned)
            painter.setPen(QColor("#808080"))
            painter.drawText(self.width - 80, y_offset, col.data_type)
            
            y_offset += self.row_height

    def update_columns_visual(self, columns_list):
        self.columns_list = columns_list
        # Resize height based on content
        self.height = self.header_height + 25 + (len(columns_list) * self.row_height)
        self.update() # Trigger repaint

    def mouseDoubleClickEvent(self, event):
        self.comms.request_edit_table.emit(self.table_name)
        super().mouseDoubleClickEvent(event)

    def contextMenuEvent(self, event):
        menu = QMenu()
        # Modern Stylesheet for Menu
        menu.setStyleSheet("""
            QMenu { background-color: #2b2b2b; color: #ffffff; border: 1px solid #555; }
            QMenu::item { padding: 5px 20px; }
            QMenu::item:selected { background-color: #3d3d3d; }
        """)
        
        edit_action = menu.addAction("✏️ Edit Table")
        data_action = menu.addAction("📝 Insert Data") # NEW
        menu.addSeparator()
        del_action = menu.addAction("🗑️ Delete Table")
        
        selected = menu.exec(event.screenPos())
        
        if selected == edit_action:
            self.comms.request_edit_table.emit(self.table_name)
        elif selected == del_action:
            self.comms.request_delete_table.emit(self.table_name)
        elif selected == data_action:
            self.comms.request_insert_data.emit(self.table_name)

    def itemChange(self, change, value):
        if change == QGraphicsItem.ItemPositionChange:
            for line in self.lines:
                line.update_position()
        return super().itemChange(change, value)

class SchemaCanvas(QGraphicsView):
    def __init__(self, comms):
        super().__init__()
        self.comms = comms
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)
        self.setSceneRect(0, 0, 4000, 4000)
        
        # Dark Grid Background
        self.setBackgroundBrush(QBrush(QColor("#181818")))
        
        self.table_items = {} 
        self.connector_items = []

    def drawBackground(self, painter, rect):
        # Draw Cool Grid
        super().drawBackground(painter, rect)
        grid_size = 40
        left = int(rect.left()) - (int(rect.left()) % grid_size)
        top = int(rect.top()) - (int(rect.top()) % grid_size)
        
        lines = []
        # Vertical
        for x in range(left, int(rect.right()), grid_size):
            lines.append(QLineF(x, rect.top(), x, rect.bottom()))
        # Horizontal
        for y in range(top, int(rect.bottom()), grid_size):
            lines.append(QLineF(rect.left(), y, rect.right(), y))

        painter.setPen(QPen(QColor("#222222"), 1))
        painter.drawLines(lines)

    def add_table_visual(self, name, x=100, y=100):
        item = TableItem(name, x, y, self.comms)
        # Add Drop Shadow
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0, 0, 0, 150))
        shadow.setOffset(5, 5)
        item.setGraphicsEffect(shadow)
        
        self.scene.addItem(item)
        self.table_items[name] = item

    def remove_table_visual(self, name):
        if name in self.table_items:
            item = self.table_items[name]
            for line in item.lines[:]: 
                self.scene.removeItem(line)
                if line in self.connector_items: self.connector_items.remove(line)
            self.scene.removeItem(item)
            del self.table_items[name]

    def update_table_visual(self, name, cols):
        if name in self.table_items:
            self.table_items[name].update_columns_visual(cols)

    def rename_table_visual(self, old_name, new_name):
        if old_name in self.table_items:
            item = self.table_items[old_name]
            item.table_name = new_name
            self.table_items[new_name] = item
            del self.table_items[old_name]
            item.update()

    def add_connector(self, from_name, to_name, rel_type):
        if from_name in self.table_items and to_name in self.table_items:
            start = self.table_items[from_name]
            end = self.table_items[to_name]
            line = ConnectorLine(start, end, rel_type, self.comms)
            self.scene.addItem(line)
            start.lines.append(line)
            end.lines.append(line)
            self.connector_items.append(line)

    def remove_connector_visual(self, from_name, to_name):
        for line in self.connector_items:
            if line.start_item.table_name == from_name and line.end_item.table_name == to_name:
                self.scene.removeItem(line)
                line.start_item.lines.remove(line)
                line.end_item.lines.remove(line)
                self.connector_items.remove(line)
                break
