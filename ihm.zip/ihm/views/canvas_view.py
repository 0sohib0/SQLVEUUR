from PySide6.QtWidgets import (QGraphicsScene, QGraphicsView, QGraphicsItem, QMenu, QGraphicsLineItem, 
                               QGraphicsDropShadowEffect, QListWidget, QListWidgetItem, QGraphicsTextItem)
from PySide6.QtCore import Qt, QPointF, Signal, QObject, QLineF, QRectF, QMimeData, QSize
from PySide6.QtGui import QBrush, QPen, QColor, QFont, QPainter, QLinearGradient, QPainterPath, QDrag, QRadialGradient

class Communicate(QObject):
    request_edit_table = Signal(str)
    request_delete_table = Signal(str)
    request_delete_rel = Signal(str, str)
    request_insert_data = Signal(str)
    request_create_table_at = Signal(float, float)

class ToolboxWidget(QListWidget):
    def __init__(self):
        super().__init__()
        self.setDragEnabled(True)
        self.setViewMode(QListWidget.IconMode)
        self.setIconSize(QSize(45, 45))
        self.setSpacing(12)
        self.setAcceptDrops(False)
        # ستايل الصندوق الجانبي العائم
        self.setStyleSheet("""
            QListWidget { 
                background-color: #252526; 
                border: none;
                border-radius: 8px;
                outline: none;
            } 
            QListWidget::item { 
                background-color: #333333; 
                color: #e0e0e0;
                border-radius: 6px;
                margin: 2px;
            }
            QListWidget::item:hover { 
                background-color: #444444; 
                border: 1px solid #505050;
            }
        """)

        item = QListWidgetItem("📄 New Table")
        item.setTextAlignment(Qt.AlignCenter)
        font = QFont("Segoe UI", 9, QFont.Bold)
        item.setFont(font)
        item.setToolTip("Drag to Canvas")
        self.addItem(item)

    def startDrag(self, supportedActions):
        item = self.currentItem()
        mime_data = QMimeData()
        mime_data.setText("CREATE_TABLE")
        drag = QDrag(self)
        drag.setMimeData(mime_data)
        drag.exec(supportedActions)

class ConnectorLine(QGraphicsLineItem):
    def __init__(self, start_item, end_item, rel_type, comms):
        super().__init__()
        self.start_item = start_item
        self.end_item = end_item
        self.rel_type = rel_type
        self.comms = comms
        self.setZValue(-2) 
        self.setFlag(QGraphicsItem.ItemIsSelectable)
        
        # خط أكثر نعومة ولون أفتح قليلاً
        pen = QPen(QColor("#707070"), 2)
        pen.setCapStyle(Qt.RoundCap)
        self.setPen(pen)
        
        self.start_label = QGraphicsTextItem("", self)
        self.end_label = QGraphicsTextItem("", self)
        self.setup_labels()
        self.update_position()

    def setup_labels(self):
        font = QFont("Arial", 9, QFont.Bold)
        self.start_label.setFont(font); self.end_label.setFont(font)
        self.start_label.setDefaultTextColor(QColor("#ff6b6b")) # لون برتقالي محمر
        self.end_label.setDefaultTextColor(QColor("#ff6b6b"))
        if self.rel_type == "1-N": self.start_label.setPlainText("N"); self.end_label.setPlainText("1")
        elif self.rel_type == "N-N": self.start_label.setPlainText("N"); self.end_label.setPlainText("N") 
    
    def update_position(self):
        start_pos = self.start_item.scenePos() + QPointF(self.start_item.boundingRect().width()/2, self.start_item.boundingRect().height()/2)
        end_pos = self.end_item.scenePos() + QPointF(self.end_item.boundingRect().width()/2, self.end_item.boundingRect().height()/2)
        line = QLineF(start_pos, end_pos)
        self.setLine(line)
        self.start_label.setPos(line.pointAt(0.15))
        self.end_label.setPos(line.pointAt(0.85))

    def contextMenuEvent(self, event):
        menu = QMenu()
        menu.setStyleSheet("QMenu { background-color: #252526; color: white; border: 1px solid #444; } QMenu::item:selected { background-color: #094771; }")
        del_action = menu.addAction("❌ Delete Connection")
        if menu.exec(event.screenPos()) == del_action: self.comms.request_delete_rel.emit(self.start_item.table_name, self.end_item.table_name)

class TableItem(QGraphicsItem):
    def __init__(self, table_name, x, y, comms):
        super().__init__()
        self.setPos(x, y); self.comms = comms; self.table_name = table_name
        self.columns_list = []; self.lines = []
        self.setFlags(QGraphicsItem.ItemIsMovable | QGraphicsItem.ItemIsSelectable | QGraphicsItem.ItemSendsGeometryChanges)
        self.width = 200; self.header_height = 40; self.row_height = 24; self.height = 100 
    
    def boundingRect(self): return QRectF(0, 0, self.width, self.height)
    
    def paint(self, painter, option, widget):
        # 1. رسم جسم الجدول (الخلفية)
        path = QPainterPath()
        path.addRoundedRect(self.boundingRect(), 8, 8)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # تعبئة بلون داكن ناعم
        painter.fillPath(path, QBrush(QColor("#1e1e1e")))
        
        # حدود الجدول (تتغير عند التحديد)
        if self.isSelected():
            painter.setPen(QPen(QColor("#007acc"), 2)) # أزرق عند التحديد
        else:
            painter.setPen(QPen(QColor("#3e3e42"), 1))
        painter.drawPath(path)

        # 2. رسم الرأس (Header) بتدرج لوني عصري
        header_path = QPainterPath()
        header_path.addRoundedRect(0, 0, self.width, self.header_height, 8, 8)
        
        painter.save()
        painter.setClipRect(0, 0, self.width, self.header_height) # قص الجزء السفلي ليبقى مستقيماً
        
        grad = QLinearGradient(0, 0, self.width, 0) # تدرج أفقي
        grad.setColorAt(0, QColor("#2d2d30")) 
        grad.setColorAt(1, QColor("#3e3e42"))
        
        painter.fillPath(header_path, QBrush(grad))
        
        # خط فاصل تحت العنوان
        painter.setPen(QPen(QColor("#007acc"), 2))
        painter.drawLine(0, self.header_height, self.width, self.header_height)
        
        painter.restore()

        # 3. النص (اسم الجدول)
        painter.setPen(Qt.white)
        painter.setFont(QFont("Segoe UI", 10, QFont.Bold))
        painter.drawText(QRectF(0, 0, self.width, self.header_height), Qt.AlignCenter, self.table_name)

        # 4. الأعمدة
        y_offset = self.header_height + 20
        painter.setFont(QFont("Consolas", 9)) # خط مبرمجين للأعمدة
        
        for col in self.columns_list:
            # أيقونة المفتاح أو العمود
            icon = "🔑" if col.is_pk else "•"
            color = QColor("#ffcc00") if col.is_pk else QColor("#858585")
            
            painter.setPen(color)
            painter.drawText(15, y_offset, icon)
            
            # اسم العمود
            painter.setPen(QColor("#cccccc"))
            painter.drawText(35, y_offset, col.name)
            
            # نوع البيانات (بلون باهت)
            painter.setPen(QColor("#569cd6")) # أزرق فاتح مثل VS Code
            painter.drawText(self.width - 90, y_offset, col.data_type)
            
            y_offset += self.row_height

    def update_columns_visual(self, columns_list):
        self.columns_list = columns_list
        self.height = self.header_height + 25 + (len(columns_list) * self.row_height)
        self.update() 

    def mouseDoubleClickEvent(self, event): self.comms.request_edit_table.emit(self.table_name); super().mouseDoubleClickEvent(event)
    
    def contextMenuEvent(self, event):
        menu = QMenu()
        menu.setStyleSheet("QMenu { background-color: #252526; color: white; border: 1px solid #333; } QMenu::item:selected { background-color: #094771; }")
        edit = menu.addAction("✏️ Edit"); data = menu.addAction("📝 Data"); menu.addSeparator(); rm = menu.addAction("🗑️ Delete")
        sel = menu.exec(event.screenPos())
        if sel == edit: self.comms.request_edit_table.emit(self.table_name)
        elif sel == rm: self.comms.request_delete_table.emit(self.table_name)
        elif sel == data: self.comms.request_insert_data.emit(self.table_name)
    
    def itemChange(self, change, value):
        if change == QGraphicsItem.ItemPositionChange: 
            for line in self.lines: line.update_position()
        return super().itemChange(change, value)

class SchemaCanvas(QGraphicsView):
    def __init__(self, comms):
        super().__init__()
        self.comms = comms
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)
        self.setSceneRect(0, 0, 5000, 5000)
        
        # خلفية داكنة جداً (Deep Dark)
        self.setBackgroundBrush(QBrush(QColor("#101010")))
        
        self.table_items = {}
        self.connector_items = []
        self.setAcceptDrops(True)
        
        # إعدادات الرسم عالي الجودة
        self.setRenderHint(QPainter.Antialiasing)
        self.setRenderHint(QPainter.TextAntialiasing)
        self.setRenderHint(QPainter.SmoothPixmapTransform)

    def drawBackground(self, painter, rect):
        super().drawBackground(painter, rect)
        
        # رسم شبكة منقطة (Dot Grid) بدلاً من الخطوط
        grid_size = 25
        left = int(rect.left()) - (int(rect.left()) % grid_size)
        top = int(rect.top()) - (int(rect.top()) % grid_size)
        
        points = []
        for x in range(left, int(rect.right()), grid_size):
            for y in range(top, int(rect.bottom()), grid_size):
                points.append(QPointF(x, y))
        
        painter.setPen(QPen(QColor("#333333"), 1))
        painter.drawPoints(points)

    def dragEnterEvent(self, event):
        if event.mimeData().text() == "CREATE_TABLE": event.accept()
        else: event.ignore()
    def dragMoveEvent(self, event):
        if event.mimeData().text() == "CREATE_TABLE": event.accept()
        else: event.ignore()
    def dropEvent(self, event):
        if event.mimeData().text() == "CREATE_TABLE":
            pos = self.mapToScene(event.position().toPoint())
            self.comms.request_create_table_at.emit(pos.x(), pos.y())
            event.accept()
        else: event.ignore()

    def add_table_visual(self, name, x=100, y=100):
        item = TableItem(name, x, y, self.comms)
        # ظل ناعم جداً
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(25)
        shadow.setColor(QColor(0,0,0,180))
        shadow.setOffset(0, 5)
        item.setGraphicsEffect(shadow)
        self.scene.addItem(item); self.table_items[name] = item
    
    def remove_table_visual(self, name):
        if name in self.table_items:
            item = self.table_items[name]
            for line in item.lines[:]: self.scene.removeItem(line); 
            if item.lines: self.connector_items = [c for c in self.connector_items if c not in item.lines]
            self.scene.removeItem(item); del self.table_items[name]
    def update_table_visual(self, name, cols):
        if name in self.table_items: self.table_items[name].update_columns_visual(cols)
    def rename_table_visual(self, old_name, new_name):
        if old_name in self.table_items:
            item = self.table_items[old_name]; item.table_name = new_name; self.table_items[new_name] = item; del self.table_items[old_name]; item.update()
    def add_connector(self, from_name, to_name, rel_type):
        if from_name in self.table_items and to_name in self.table_items:
            start = self.table_items[from_name]; end = self.table_items[to_name]
            line = ConnectorLine(start, end, rel_type, self.comms)
            self.scene.addItem(line); start.lines.append(line); end.lines.append(line); self.connector_items.append(line)
    def remove_connector_visual(self, from_name, to_name):
        for line in self.connector_items:
            if line.start_item.table_name == from_name and line.end_item.table_name == to_name:
                self.scene.removeItem(line); line.start_item.lines.remove(line); line.end_item.lines.remove(line); self.connector_items.remove(line); break
