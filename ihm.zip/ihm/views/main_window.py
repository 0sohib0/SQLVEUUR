from PySide6.QtWidgets import (QMainWindow, QVBoxLayout, QWidget, QPushButton, 
                                 QInputDialog, QHBoxLayout, QTextEdit, QTableWidget, 
                                 QTableWidgetItem, QSplitter, QLabel, QMessageBox, QDialog,
                                 QFormLayout, QComboBox, QListWidget, QLineEdit, QHeaderView)
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon, QFont
from .canvas_view import SchemaCanvas, Communicate

# --- STYLESHEET (The Magic) ---
DARK_THEME = """
QMainWindow { background-color: #1e1e1e; color: #ffffff; }
QWidget { color: #f0f0f0; font-family: 'Segoe UI'; font-size: 14px; }
QPushButton { 
    background-color: #3a3a3a; 
    border: 1px solid #555; 
    border-radius: 6px; 
    padding: 8px 15px;
    font-weight: bold;
}
QPushButton:hover { background-color: #505050; border-color: #777; }
QPushButton:pressed { background-color: #2575fc; color: white; border: none; }
QLineEdit, QComboBox, QTextEdit { 
    background-color: #2b2b2b; 
    border: 1px solid #444; 
    border-radius: 4px; 
    padding: 5px; 
    color: white;
}
QTableWidget { 
    background-color: #2b2b2b; 
    gridline-color: #444; 
    border: none;
    selection-background-color: #2575fc;
}
QHeaderView::section {
    background-color: #333;
    padding: 4px;
    border: 1px solid #444;
}
QLabel { font-weight: bold; color: #ccc; }
QSplitter::handle { background-color: #333; }
"""

# --- Insert Data Dialog ---
class DataEntryDialog(QDialog):
    def __init__(self, table_name, columns):
        super().__init__()
        self.setWindowTitle(f"Insert Data into {table_name}")
        self.resize(400, 300)
        self.table_name = table_name
        self.columns = columns
        self.inputs = {}
        
        layout = QFormLayout(self)
        layout.addRow(QLabel(f"Enter values for {table_name}:"))
        
        for col in columns:
            inp = QLineEdit()
            inp.setPlaceholderText(f"Type: {col.data_type}")
            layout.addRow(f"{col.name}:", inp)
            self.inputs[col.name] = inp
            
        btn = QPushButton("Insert Data")
        btn.clicked.connect(self.accept)
        layout.addRow(btn)

    def get_values(self):
        # Return dict {col: value}
        vals = {}
        for name, inp in self.inputs.items():
            vals[name] = inp.text()
        return vals

class TableCreationDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Create New Table")
        self.resize(300, 200)
        layout = QFormLayout(self)
        self.name_edit = QLineEdit(); self.name_edit.setPlaceholderText("e.g. Users")
        self.pk_name_edit = QLineEdit("id"); self.pk_name_edit.setPlaceholderText("Primary Key Name")
        self.pk_type_combo = QComboBox(); self.pk_type_combo.addItems(["INTEGER", "VARCHAR(36)", "BIGINT"])
        layout.addRow("Table Name:", self.name_edit)
        layout.addRow("PK Name:", self.pk_name_edit)
        layout.addRow("PK Type:", self.pk_type_combo)
        btn = QPushButton("Create Table"); btn.clicked.connect(self.accept)
        layout.addRow(btn)
    def get_data(self): return self.name_edit.text(), self.pk_name_edit.text(), self.pk_type_combo.currentText().split(" ")[0]

class RelationshipDialog(QDialog):
    def __init__(self, table_names):
        super().__init__()
        self.setWindowTitle("Create Relationship")
        self.resize(300, 150)
        layout = QFormLayout(self)
        self.source_combo = QComboBox(); self.source_combo.addItems(table_names)
        self.target_combo = QComboBox(); self.target_combo.addItems(table_names)
        self.rel_type = QComboBox(); self.rel_type.addItems(["1-N", "N-N"])
        layout.addRow("From Table:", self.source_combo)
        layout.addRow("To Table:", self.target_combo)
        layout.addRow("Type:", self.rel_type)
        btn = QPushButton("Connect"); btn.clicked.connect(self.accept)
        layout.addRow(btn)
    def get_data(self): return self.source_combo.currentText(), self.target_combo.currentText(), self.rel_type.currentText()

class TableEditorDialog(QDialog):
    def __init__(self, table_name, columns):
        super().__init__()
        self.setWindowTitle(f"Edit Table: {table_name}")
        self.resize(400, 300)
        self.layout = QVBoxLayout(self)
        self.name_edit = QLineEdit(table_name)
        self.layout.addWidget(QLabel("Table Name:"))
        self.layout.addWidget(self.name_edit)
        self.col_list = QListWidget()
        for col in columns: self.col_list.addItem(f"{col.name} ({col.data_type})")
        self.layout.addWidget(QLabel("Columns:"))
        self.layout.addWidget(self.col_list)
        add_layout = QHBoxLayout()
        self.new_col_name = QLineEdit(); self.new_col_name.setPlaceholderText("New Column")
        self.new_col_type = QComboBox(); self.new_col_type.addItems(["VARCHAR(255)", "INTEGER", "TEXT", "BOOLEAN", "DATE"])
        btn_add = QPushButton("+ Add"); btn_add.clicked.connect(self.add_column_handler)
        add_layout.addWidget(self.new_col_name); add_layout.addWidget(self.new_col_type); add_layout.addWidget(btn_add)
        self.layout.addLayout(add_layout)
        btn_del = QPushButton("Delete Selected"); btn_del.clicked.connect(self.delete_col_handler); self.layout.addWidget(btn_del)
        btn_save = QPushButton("Save & Close"); btn_save.clicked.connect(self.accept); self.layout.addWidget(btn_save)
        self.added_cols = []; self.deleted_cols = []
    def add_column_handler(self):
        if self.new_col_name.text():
            self.added_cols.append((self.new_col_name.text(), self.new_col_type.currentText()))
            self.col_list.addItem(f"{self.new_col_name.text()} ({self.new_col_type.currentText()})")
            self.new_col_name.clear()
    def delete_col_handler(self):
        row = self.col_list.currentRow()
        if self.col_list.currentItem(): self.deleted_cols.append(self.col_list.currentItem().text().split(" ")[0]); self.col_list.takeItem(row)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ultimate DB Designer v6.0")
        self.resize(1280, 850)
        self.setStyleSheet(DARK_THEME) # APPLY THEME

        self.comms = Communicate()
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)

        # Toolbar
        tools_layout = QVBoxLayout()
        self.btn_add_table = QPushButton("➕ Table")
        self.btn_add_rel = QPushButton("🔗 Connect")
        self.btn_gen_sql = QPushButton("📄 SQL Code")
        self.btn_exec_sql = QPushButton("▶ Run SQL")
        
        tools_layout.addWidget(QLabel("DESIGNER"))
        tools_layout.addWidget(self.btn_add_table)
        tools_layout.addWidget(self.btn_add_rel)
        tools_layout.addSpacing(20)
        tools_layout.addWidget(QLabel("ENGINE"))
        tools_layout.addWidget(self.btn_gen_sql)
        tools_layout.addWidget(self.btn_exec_sql)
        tools_layout.addStretch()

        self.canvas = SchemaCanvas(self.comms)
        
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        self.sql_display = QTextEdit()
        self.sql_display.setPlaceholderText("Write SQL here (CREATE TABLE, INSERT, SELECT...)")
        self.result_table = QTableWidget()
        
        right_layout.addWidget(QLabel("SQL Console:"))
        right_layout.addWidget(self.sql_display)
        right_layout.addWidget(QLabel("Results:"))
        right_layout.addWidget(self.result_table)

        splitter = QSplitter(Qt.Horizontal)
        tools_w = QWidget(); tools_w.setLayout(tools_layout)
        splitter.addWidget(tools_w)
        splitter.addWidget(self.canvas)
        splitter.addWidget(right_panel)
        splitter.setStretchFactor(1, 4)
        splitter.setStretchFactor(2, 2)

        main_layout.addWidget(splitter)

    def display_results(self, columns, rows):
        self.result_table.clear()
        self.result_table.setColumnCount(len(columns))
        self.result_table.setHorizontalHeaderLabels(columns)
        self.result_table.setRowCount(len(rows))
        header = self.result_table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Stretch)
        for r_idx, row_data in enumerate(rows):
            for c_idx, data in enumerate(row_data):
                self.result_table.setItem(r_idx, c_idx, QTableWidgetItem(str(data)))
