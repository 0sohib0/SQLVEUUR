from PySide6.QtWidgets import (QMainWindow, QVBoxLayout, QWidget, QPushButton, 
                                 QInputDialog, QHBoxLayout, QTextEdit, QTableWidget, 
                                 QTableWidgetItem, QSplitter, QLabel, QMessageBox, QDialog,
                                 QFormLayout, QComboBox, QListWidget, QLineEdit, QHeaderView, QFileDialog, QFrame)
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QKeySequence, QFont, QColor, QPalette
from .canvas_view import SchemaCanvas, Communicate, ToolboxWidget

# --- MODERN PRO THEME (ستايل CSS احترافي) ---
MODERN_THEME = """
QMainWindow { background-color: #121212; color: #ffffff; }

/* Menu Bar */
QMenuBar { background-color: #1e1e1e; color: #cccccc; padding: 5px; border-bottom: 1px solid #333; }
QMenuBar::item { padding: 5px 10px; background: transparent; }
QMenuBar::item:selected { background-color: #333333; border-radius: 4px; color: white; }
QMenu { background-color: #1e1e1e; border: 1px solid #333; padding: 5px; }
QMenu::item { padding: 5px 20px; color: #cccccc; }
QMenu::item:selected { background-color: #094771; color: white; border-radius: 4px; }

/* Buttons */
QPushButton { 
    background-color: #2d2d30; 
    border: 1px solid #3e3e42; 
    border-radius: 6px; 
    padding: 8px 16px; 
    font-family: 'Segoe UI';
    font-weight: 600;
    color: #f0f0f0;
}
QPushButton:hover { background-color: #3e3e42; border-color: #555; }
QPushButton:pressed { background-color: #007acc; border-color: #007acc; }
QPushButton:checked { background-color: #007acc; border-color: #007acc; }

/* Inputs */
QLineEdit, QComboBox, QTextEdit { 
    background-color: #1e1e1e; 
    border: 1px solid #3e3e42; 
    border-radius: 5px; 
    padding: 6px; 
    color: #dcdcdc;
    selection-background-color: #264f78;
}
QLineEdit:focus, QTextEdit:focus { border: 1px solid #007acc; }

/* Table Results */
QTableWidget { 
    background-color: #1e1e1e; 
    gridline-color: #333; 
    border: none; 
    selection-background-color: #264f78;
}
QHeaderView::section { 
    background-color: #252526; 
    padding: 6px; 
    border: none; 
    border-bottom: 1px solid #3e3e42;
    font-weight: bold;
    color: #cccccc;
}

/* Splitter */
QSplitter::handle { background-color: #2d2d30; }

/* Labels */
QLabel { font-family: 'Segoe UI'; font-weight: 600; color: #aaaaaa; letter-spacing: 0.5px; }
"""

class DataEntryDialog(QDialog):
    def __init__(self, table_name, columns):
        super().__init__(); self.setWindowTitle(f"Insert into {table_name}"); self.resize(400, 300); self.inputs = {}
        layout = QFormLayout(self)
        for col in columns: inp = QLineEdit(); inp.setPlaceholderText(col.data_type); layout.addRow(f"{col.name}:", inp); self.inputs[col.name] = inp
        btn = QPushButton("Insert"); btn.clicked.connect(self.accept); layout.addRow(btn)
    def get_values(self): return {name: inp.text() for name, inp in self.inputs.items()}

class TableCreationDialog(QDialog):
    def __init__(self):
        super().__init__(); self.setWindowTitle("New Table"); self.resize(300, 200); layout = QFormLayout(self)
        self.name_edit = QLineEdit(); self.pk_name_edit = QLineEdit("id"); self.pk_type_combo = QComboBox(); self.pk_type_combo.addItems(["INTEGER", "VARCHAR(36)"])
        layout.addRow("Name:", self.name_edit); layout.addRow("PK:", self.pk_name_edit); layout.addRow("Type:", self.pk_type_combo)
        btn = QPushButton("Create"); btn.clicked.connect(self.accept); layout.addRow(btn)
    def get_data(self): return self.name_edit.text(), self.pk_name_edit.text(), self.pk_type_combo.currentText().split(" ")[0]

class RelationshipDialog(QDialog):
    def __init__(self, table_names):
        super().__init__(); self.setWindowTitle("Relationship"); self.resize(300, 150); layout = QFormLayout(self)
        self.src = QComboBox(); self.src.addItems(table_names); self.tgt = QComboBox(); self.tgt.addItems(table_names); self.type = QComboBox(); self.type.addItems(["1-N", "N-N"])
        layout.addRow("From:", self.src); layout.addRow("To:", self.tgt); layout.addRow("Type:", self.type)
        btn = QPushButton("Link"); btn.clicked.connect(self.accept); layout.addRow(btn)
    def get_data(self): return self.src.currentText(), self.tgt.currentText(), self.type.currentText()

class TableEditorDialog(QDialog):
    def __init__(self, table_name, columns):
        super().__init__(); self.setWindowTitle(f"Edit {table_name}"); self.resize(400, 300); self.layout = QVBoxLayout(self)
        self.name_edit = QLineEdit(table_name); self.layout.addWidget(QLabel("Name:")); self.layout.addWidget(self.name_edit)
        self.col_list = QListWidget(); 
        for col in columns: self.col_list.addItem(f"{col.name} ({col.data_type})")
        self.layout.addWidget(self.col_list)
        h = QHBoxLayout(); self.n_col = QLineEdit(); self.n_type = QComboBox(); self.n_type.addItems(["VARCHAR", "INTEGER", "TEXT", "DATE"])
        btn = QPushButton("+"); btn.clicked.connect(self.add_c); h.addWidget(self.n_col); h.addWidget(self.n_type); h.addWidget(btn); self.layout.addLayout(h)
        b_del = QPushButton("Delete Col"); b_del.clicked.connect(self.del_c); self.layout.addWidget(b_del)
        save = QPushButton("Save"); save.clicked.connect(self.accept); self.layout.addWidget(save)
        self.added_cols = []; self.deleted_cols = []
    def add_c(self): 
        if self.n_col.text(): self.added_cols.append((self.n_col.text(), self.n_type.currentText())); self.col_list.addItem(f"{self.n_col.text()}"); self.n_col.clear()
    def del_c(self): 
        if self.col_list.currentItem(): self.deleted_cols.append(self.col_list.currentItem().text().split(" ")[0]); self.col_list.takeItem(self.col_list.currentRow())

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ultimate DB Designer v8.0 (Modern UI)") 
        self.resize(1300, 850)
        self.setStyleSheet(MODERN_THEME) # تطبيق الثيم الجديد
        self.comms = Communicate()

        # --- MENU BAR ---
        menu_bar = self.menuBar()
        file_menu = menu_bar.addMenu("File")
        self.act_new = QAction("New Project", self); self.act_new.setShortcut(QKeySequence.New)
        self.act_open = QAction("Open Project...", self); self.act_open.setShortcut(QKeySequence.Open)
        self.act_save = QAction("Save Project As...", self); self.act_save.setShortcut(QKeySequence.Save)
        self.act_exit = QAction("Exit", self); self.act_exit.triggered.connect(self.close)
        file_menu.addAction(self.act_new); file_menu.addAction(self.act_open); file_menu.addAction(self.act_save); file_menu.addSeparator(); file_menu.addAction(self.act_exit)

        central = QWidget(); self.setCentralWidget(central); main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0); main_layout.setSpacing(0) # إلغاء الهوامش

        # --- Left Sidebar (Tools) ---
        tools_widget = QWidget()
        tools_widget.setStyleSheet("background-color: #252526; border-right: 1px solid #333;")
        tools_widget.setFixedWidth(200)
        tools_layout = QVBoxLayout(tools_widget)
        tools_layout.setContentsMargins(10, 20, 10, 20)
        
        self.btn_toggle_toolbox = QPushButton("📦 Toolbox"); self.btn_toggle_toolbox.setCheckable(True); self.btn_toggle_toolbox.clicked.connect(self.toggle_toolbox)
        
        self.btn_add_table = QPushButton("➕ Table"); self.btn_add_rel = QPushButton("🔗 Connect")
        self.btn_gen_sql = QPushButton("📜 Generate SQL"); self.btn_exec_sql = QPushButton("▶ Run SQL")
        
        tools_layout.addWidget(QLabel("VISUAL TOOLS"))
        tools_layout.addWidget(self.btn_toggle_toolbox)
        tools_layout.addWidget(self.btn_add_table)
        tools_layout.addWidget(self.btn_add_rel)
        tools_layout.addSpacing(30)
        tools_layout.addWidget(QLabel("SQL ENGINE"))
        tools_layout.addWidget(self.btn_gen_sql)
        tools_layout.addWidget(self.btn_exec_sql)
        tools_layout.addStretch()

        self.toolbox = ToolboxWidget(); self.toolbox.setVisible(False)
        self.canvas = SchemaCanvas(self.comms)
        
        # --- Right Panel (SQL & Results) ---
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(10, 10, 10, 10)
        self.sql_display = QTextEdit()
        self.sql_display.setPlaceholderText("-- Write your SQL queries here...")
        self.sql_display.setStyleSheet("font-family: Consolas; font-size: 13px; color: #dcdcdc;")
        
        self.result_table = QTableWidget()
        right_layout.addWidget(QLabel("SQL EDITOR"))
        right_layout.addWidget(self.sql_display)
        right_layout.addWidget(QLabel("QUERY RESULTS"))
        right_layout.addWidget(self.result_table)

        # Splitter Layout
        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(tools_widget)
        splitter.addWidget(self.toolbox)
        splitter.addWidget(self.canvas)
        splitter.addWidget(right_panel)
        splitter.setStretchFactor(2, 5) # Canvas takes most space

        main_layout.addWidget(splitter)

    def toggle_toolbox(self):
        v = self.btn_toggle_toolbox.isChecked(); self.toolbox.setVisible(v)
        if v: self.toolbox.setMaximumWidth(160)
    def display_results(self, columns, rows):
        self.result_table.clear(); self.result_table.setColumnCount(len(columns)); self.result_table.setHorizontalHeaderLabels(columns); self.result_table.setRowCount(len(rows))
        self.result_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        for r, row in enumerate(rows):
            for c, data in enumerate(row): self.result_table.setItem(r, c, QTableWidgetItem(str(data)))
