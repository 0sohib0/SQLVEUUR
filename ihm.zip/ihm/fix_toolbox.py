import os

# ---------------------------------------------------------
# إصلاح ملف: views/canvas_view.py
# التصحيح: استيراد QSize واستخدامه بشكل صحيح
# ---------------------------------------------------------
canvas_code = """from PySide6.QtWidgets import (QGraphicsScene, QGraphicsView, QGraphicsItem, QMenu, QGraphicsLineItem, 
                               QGraphicsDropShadowEffect, QListWidget, QListWidgetItem, QGraphicsTextItem)
from PySide6.QtCore import Qt, QPointF, Signal, QObject, QLineF, QRectF, QMimeData, QSize
from PySide6.QtGui import QBrush, QPen, QColor, QFont, QPainter, QLinearGradient, QPainterPath, QDrag

class Communicate(QObject):
    request_edit_table = Signal(str)
    request_delete_table = Signal(str)
    request_delete_rel = Signal(str, str)
    request_insert_data = Signal(str)
    request_create_table_at = Signal(float, float)

# --- Toolbox القائمة الجانبية ---
class ToolboxWidget(QListWidget):
    def __init__(self):
        super().__init__()
        self.setDragEnabled(True)
        self.setViewMode(QListWidget.IconMode)
        # --- التصحيح هنا: استخدام QSize مباشرة ---
        self.setIconSize(QSize(40, 40)) 
        self.setSpacing(10)
        self.setAcceptDrops(False)
        self.setStyleSheet("QListWidget { background-color: #2b2b2b; border: 1px solid #444; color: white; } QListWidget::item:hover { background-color: #505050; }")

        item = QListWidgetItem("New Table")
        item.setTextAlignment(Qt.AlignCenter)
        font = QFont(); font.setBold(True); item.setFont(font)
        item.setToolTip("Drag this to the canvas")
        self.addItem(item)

    def startDrag(self, supportedActions):
        item = self.currentItem()
        mime_data = QMimeData()
        mime_data.setText("CREATE_TABLE")
        drag = QDrag(self)
        drag.setMimeData(mime_data)
        drag.exec(supportedActions)

class ConnectorLine(QGraphicsLineItem):
    def __init__(self, start_item, end_item, rel_type, comms):
        super().__init__()
        self.start_item = start_item
        self.end_item = end_item
        self.rel_type = rel_type
        self.comms = comms
        self.setZValue(-2) 
        self.setFlag(QGraphicsItem.ItemIsSelectable)
        pen = QPen(QColor("#a0a0a0"), 2); pen.setStyle(Qt.DashLine)
        self.setPen(pen)
        self.start_label = QGraphicsTextItem("", self); self.end_label = QGraphicsTextItem("", self)
        self.setup_labels(); self.update_position()
    def setup_labels(self):
        font = QFont("Segoe UI", 10, QFont.Bold)
        self.start_label.setFont(font); self.end_label.setFont(font)
        self.start_label.setDefaultTextColor(QColor("#ff5555")); self.end_label.setDefaultTextColor(QColor("#ff5555"))
        if self.rel_type == "1-N": self.start_label.setPlainText("N"); self.end_label.setPlainText("1")
        elif self.rel_type == "N-N": self.start_label.setPlainText("N"); self.end_label.setPlainText("N") 
    def update_position(self):
        start_pos = self.start_item.scenePos() + QPointF(self.start_item.boundingRect().width()/2, self.start_item.boundingRect().height()/2)
        end_pos = self.end_item.scenePos() + QPointF(self.end_item.boundingRect().width()/2, self.end_item.boundingRect().height()/2)
        line = QLineF(start_pos, end_pos); self.setLine(line)
        self.start_label.setPos(line.pointAt(0.15)); self.end_label.setPos(line.pointAt(0.85))
    def contextMenuEvent(self, event):
        menu = QMenu()
        menu.setStyleSheet("QMenu { background-color: #333; color: white; }")
        del_action = menu.addAction("❌ Delete Connection")
        if menu.exec(event.screenPos()) == del_action: self.comms.request_delete_rel.emit(self.start_item.table_name, self.end_item.table_name)

class TableItem(QGraphicsItem):
    def __init__(self, table_name, x, y, comms):
        super().__init__()
        self.setPos(x, y); self.comms = comms; self.table_name = table_name
        self.columns_list = []; self.lines = []
        self.setFlags(QGraphicsItem.ItemIsMovable | QGraphicsItem.ItemIsSelectable | QGraphicsItem.ItemSendsGeometryChanges)
        self.width = 180; self.header_height = 35; self.row_height = 20; self.height = 100 
    def boundingRect(self): return QRectF(0, 0, self.width, self.height)
    def paint(self, painter, option, widget):
        path = QPainterPath(); path.addRoundedRect(self.boundingRect(), 10, 10)
        painter.setRenderHint(QPainter.Antialiasing); painter.fillPath(path, QBrush(QColor("#2d2d2d"))); painter.setPen(QPen(QColor("#444"), 1)); painter.drawPath(path)
        header_path = QPainterPath(); header_path.addRoundedRect(0, 0, self.width, self.header_height, 10, 10)
        painter.save(); painter.setClipRect(0, 0, self.width, self.header_height)
        grad = QLinearGradient(0, 0, self.width, self.header_height); grad.setColorAt(0, QColor("#6a11cb")); grad.setColorAt(1, QColor("#2575fc")) 
        painter.fillPath(header_path, QBrush(grad)); painter.restore()
        painter.setPen(Qt.white); painter.setFont(QFont("Segoe UI", 11, QFont.Bold)); painter.drawText(QRectF(0, 0, self.width, self.header_height), Qt.AlignCenter, self.table_name)
        y_offset = self.header_height + 20; painter.setFont(QFont("Consolas", 9))
        for col in self.columns_list:
            icon = "🔑" if col.is_pk else "🔹"; color = QColor("#ffeb3b") if col.is_pk else QColor("#a0a0a0")
            painter.setPen(color); painter.drawText(10, y_offset, icon)
            painter.setPen(QColor("#e0e0e0")); painter.drawText(35, y_offset, col.name)
            painter.setPen(QColor("#808080")); painter.drawText(self.width - 80, y_offset, col.data_type)
            y_offset += self.row_height
    def update_columns_visual(self, columns_list):
        self.columns_list = columns_list; self.height = self.header_height + 25 + (len(columns_list) * self.row_height); self.update() 
    def mouseDoubleClickEvent(self, event): self.comms.request_edit_table.emit(self.table_name); super().mouseDoubleClickEvent(event)
    def contextMenuEvent(self, event):
        menu = QMenu(); menu.setStyleSheet("QMenu { background-color: #2b2b2b; color: #ffffff; }")
        edit = menu.addAction("✏️ Edit"); data = menu.addAction("📝 Insert Data"); menu.addSeparator(); rm = menu.addAction("🗑️ Delete")
        sel = menu.exec(event.screenPos())
        if sel == edit: self.comms.request_edit_table.emit(self.table_name)
        elif sel == rm: self.comms.request_delete_table.emit(self.table_name)
        elif sel == data: self.comms.request_insert_data.emit(self.table_name)
    def itemChange(self, change, value):
        if change == QGraphicsItem.ItemPositionChange: 
            for line in self.lines: line.update_position()
        return super().itemChange(change, value)

class SchemaCanvas(QGraphicsView):
    def __init__(self, comms):
        super().__init__()
        self.comms = comms; self.scene = QGraphicsScene(self); self.setScene(self.scene); self.setSceneRect(0, 0, 4000, 4000)
        self.setBackgroundBrush(QBrush(QColor("#181818"))); self.table_items = {}; self.connector_items = []
        self.setAcceptDrops(True)

    def drawBackground(self, painter, rect):
        super().drawBackground(painter, rect); grid_size = 40
        left = int(rect.left()) - (int(rect.left()) % grid_size); top = int(rect.top()) - (int(rect.top()) % grid_size)
        lines = []
        for x in range(left, int(rect.right()), grid_size): lines.append(QLineF(x, rect.top(), x, rect.bottom()))
        for y in range(top, int(rect.bottom()), grid_size): lines.append(QLineF(rect.left(), y, rect.right(), y))
        painter.setPen(QPen(QColor("#222222"), 1)); painter.drawLines(lines)

    def dragEnterEvent(self, event):
        if event.mimeData().text() == "CREATE_TABLE": event.accept()
        else: event.ignore()
    def dragMoveEvent(self, event):
        if event.mimeData().text() == "CREATE_TABLE": event.accept()
        else: event.ignore()
    def dropEvent(self, event):
        if event.mimeData().text() == "CREATE_TABLE":
            pos = self.mapToScene(event.position().toPoint())
            self.comms.request_create_table_at.emit(pos.x(), pos.y())
            event.accept()
        else: event.ignore()

    def add_table_visual(self, name, x=100, y=100):
        item = TableItem(name, x, y, self.comms); shadow = QGraphicsDropShadowEffect(); shadow.setBlurRadius(20); shadow.setColor(QColor(0,0,0,150)); shadow.setOffset(5,5); item.setGraphicsEffect(shadow)
        self.scene.addItem(item); self.table_items[name] = item
    def remove_table_visual(self, name):
        if name in self.table_items:
            item = self.table_items[name]
            for line in item.lines[:]: self.scene.removeItem(line); 
            if item.lines: self.connector_items = [c for c in self.connector_items if c not in item.lines]
            self.scene.removeItem(item); del self.table_items[name]
    def update_table_visual(self, name, cols):
        if name in self.table_items: self.table_items[name].update_columns_visual(cols)
    def rename_table_visual(self, old_name, new_name):
        if old_name in self.table_items:
            item = self.table_items[old_name]; item.table_name = new_name; self.table_items[new_name] = item; del self.table_items[old_name]; item.update()
    def add_connector(self, from_name, to_name, rel_type):
        if from_name in self.table_items and to_name in self.table_items:
            start = self.table_items[from_name]; end = self.table_items[to_name]
            line = ConnectorLine(start, end, rel_type, self.comms)
            self.scene.addItem(line); start.lines.append(line); end.lines.append(line); self.connector_items.append(line)
    def remove_connector_visual(self, from_name, to_name):
        for line in self.connector_items:
            if line.start_item.table_name == from_name and line.end_item.table_name == to_name:
                self.scene.removeItem(line); line.start_item.lines.remove(line); line.end_item.lines.remove(line); self.connector_items.remove(line); break
"""
with open("views/canvas_view.py", "w", encoding="utf-8") as f:
    f.write(canvas_code)

print("✅ تم إصلاح خطأ QSize!")
print("👉 الآن شغل البرنامج: python main.py")