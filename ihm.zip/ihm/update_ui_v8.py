import os

# ---------------------------------------------------------
# 1. VIEW: canvas_view.py (تحديث الرسم: شبكة منقطة + جداول عصرية)
# ---------------------------------------------------------
canvas_code = """from PySide6.QtWidgets import (QGraphicsScene, QGraphicsView, QGraphicsItem, QMenu, QGraphicsLineItem, 
                               QGraphicsDropShadowEffect, QListWidget, QListWidgetItem, QGraphicsTextItem)
from PySide6.QtCore import Qt, QPointF, Signal, QObject, QLineF, QRectF, QMimeData, QSize
from PySide6.QtGui import QBrush, QPen, QColor, QFont, QPainter, QLinearGradient, QPainterPath, QDrag, QRadialGradient

class Communicate(QObject):
    request_edit_table = Signal(str)
    request_delete_table = Signal(str)
    request_delete_rel = Signal(str, str)
    request_insert_data = Signal(str)
    request_create_table_at = Signal(float, float)

class ToolboxWidget(QListWidget):
    def __init__(self):
        super().__init__()
        self.setDragEnabled(True)
        self.setViewMode(QListWidget.IconMode)
        self.setIconSize(QSize(45, 45))
        self.setSpacing(12)
        self.setAcceptDrops(False)
        # ستايل الصندوق الجانبي العائم
        self.setStyleSheet(\"\"\"
            QListWidget { 
                background-color: #252526; 
                border: none;
                border-radius: 8px;
                outline: none;
            } 
            QListWidget::item { 
                background-color: #333333; 
                color: #e0e0e0;
                border-radius: 6px;
                margin: 2px;
            }
            QListWidget::item:hover { 
                background-color: #444444; 
                border: 1px solid #505050;
            }
        \"\"\")

        item = QListWidgetItem("📄 New Table")
        item.setTextAlignment(Qt.AlignCenter)
        font = QFont("Segoe UI", 9, QFont.Bold)
        item.setFont(font)
        item.setToolTip("Drag to Canvas")
        self.addItem(item)

    def startDrag(self, supportedActions):
        item = self.currentItem()
        mime_data = QMimeData()
        mime_data.setText("CREATE_TABLE")
        drag = QDrag(self)
        drag.setMimeData(mime_data)
        drag.exec(supportedActions)

class ConnectorLine(QGraphicsLineItem):
    def __init__(self, start_item, end_item, rel_type, comms):
        super().__init__()
        self.start_item = start_item
        self.end_item = end_item
        self.rel_type = rel_type
        self.comms = comms
        self.setZValue(-2) 
        self.setFlag(QGraphicsItem.ItemIsSelectable)
        
        # خط أكثر نعومة ولون أفتح قليلاً
        pen = QPen(QColor("#707070"), 2)
        pen.setCapStyle(Qt.RoundCap)
        self.setPen(pen)
        
        self.start_label = QGraphicsTextItem("", self)
        self.end_label = QGraphicsTextItem("", self)
        self.setup_labels()
        self.update_position()

    def setup_labels(self):
        font = QFont("Arial", 9, QFont.Bold)
        self.start_label.setFont(font); self.end_label.setFont(font)
        self.start_label.setDefaultTextColor(QColor("#ff6b6b")) # لون برتقالي محمر
        self.end_label.setDefaultTextColor(QColor("#ff6b6b"))
        if self.rel_type == "1-N": self.start_label.setPlainText("N"); self.end_label.setPlainText("1")
        elif self.rel_type == "N-N": self.start_label.setPlainText("N"); self.end_label.setPlainText("N") 
    
    def update_position(self):
        start_pos = self.start_item.scenePos() + QPointF(self.start_item.boundingRect().width()/2, self.start_item.boundingRect().height()/2)
        end_pos = self.end_item.scenePos() + QPointF(self.end_item.boundingRect().width()/2, self.end_item.boundingRect().height()/2)
        line = QLineF(start_pos, end_pos)
        self.setLine(line)
        self.start_label.setPos(line.pointAt(0.15))
        self.end_label.setPos(line.pointAt(0.85))

    def contextMenuEvent(self, event):
        menu = QMenu()
        menu.setStyleSheet("QMenu { background-color: #252526; color: white; border: 1px solid #444; } QMenu::item:selected { background-color: #094771; }")
        del_action = menu.addAction("❌ Delete Connection")
        if menu.exec(event.screenPos()) == del_action: self.comms.request_delete_rel.emit(self.start_item.table_name, self.end_item.table_name)

class TableItem(QGraphicsItem):
    def __init__(self, table_name, x, y, comms):
        super().__init__()
        self.setPos(x, y); self.comms = comms; self.table_name = table_name
        self.columns_list = []; self.lines = []
        self.setFlags(QGraphicsItem.ItemIsMovable | QGraphicsItem.ItemIsSelectable | QGraphicsItem.ItemSendsGeometryChanges)
        self.width = 200; self.header_height = 40; self.row_height = 24; self.height = 100 
    
    def boundingRect(self): return QRectF(0, 0, self.width, self.height)
    
    def paint(self, painter, option, widget):
        # 1. رسم جسم الجدول (الخلفية)
        path = QPainterPath()
        path.addRoundedRect(self.boundingRect(), 8, 8)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # تعبئة بلون داكن ناعم
        painter.fillPath(path, QBrush(QColor("#1e1e1e")))
        
        # حدود الجدول (تتغير عند التحديد)
        if self.isSelected():
            painter.setPen(QPen(QColor("#007acc"), 2)) # أزرق عند التحديد
        else:
            painter.setPen(QPen(QColor("#3e3e42"), 1))
        painter.drawPath(path)

        # 2. رسم الرأس (Header) بتدرج لوني عصري
        header_path = QPainterPath()
        header_path.addRoundedRect(0, 0, self.width, self.header_height, 8, 8)
        
        painter.save()
        painter.setClipRect(0, 0, self.width, self.header_height) # قص الجزء السفلي ليبقى مستقيماً
        
        grad = QLinearGradient(0, 0, self.width, 0) # تدرج أفقي
        grad.setColorAt(0, QColor("#2d2d30")) 
        grad.setColorAt(1, QColor("#3e3e42"))
        
        painter.fillPath(header_path, QBrush(grad))
        
        # خط فاصل تحت العنوان
        painter.setPen(QPen(QColor("#007acc"), 2))
        painter.drawLine(0, self.header_height, self.width, self.header_height)
        
        painter.restore()

        # 3. النص (اسم الجدول)
        painter.setPen(Qt.white)
        painter.setFont(QFont("Segoe UI", 10, QFont.Bold))
        painter.drawText(QRectF(0, 0, self.width, self.header_height), Qt.AlignCenter, self.table_name)

        # 4. الأعمدة
        y_offset = self.header_height + 20
        painter.setFont(QFont("Consolas", 9)) # خط مبرمجين للأعمدة
        
        for col in self.columns_list:
            # أيقونة المفتاح أو العمود
            icon = "🔑" if col.is_pk else "•"
            color = QColor("#ffcc00") if col.is_pk else QColor("#858585")
            
            painter.setPen(color)
            painter.drawText(15, y_offset, icon)
            
            # اسم العمود
            painter.setPen(QColor("#cccccc"))
            painter.drawText(35, y_offset, col.name)
            
            # نوع البيانات (بلون باهت)
            painter.setPen(QColor("#569cd6")) # أزرق فاتح مثل VS Code
            painter.drawText(self.width - 90, y_offset, col.data_type)
            
            y_offset += self.row_height

    def update_columns_visual(self, columns_list):
        self.columns_list = columns_list
        self.height = self.header_height + 25 + (len(columns_list) * self.row_height)
        self.update() 

    def mouseDoubleClickEvent(self, event): self.comms.request_edit_table.emit(self.table_name); super().mouseDoubleClickEvent(event)
    
    def contextMenuEvent(self, event):
        menu = QMenu()
        menu.setStyleSheet("QMenu { background-color: #252526; color: white; border: 1px solid #333; } QMenu::item:selected { background-color: #094771; }")
        edit = menu.addAction("✏️ Edit"); data = menu.addAction("📝 Data"); menu.addSeparator(); rm = menu.addAction("🗑️ Delete")
        sel = menu.exec(event.screenPos())
        if sel == edit: self.comms.request_edit_table.emit(self.table_name)
        elif sel == rm: self.comms.request_delete_table.emit(self.table_name)
        elif sel == data: self.comms.request_insert_data.emit(self.table_name)
    
    def itemChange(self, change, value):
        if change == QGraphicsItem.ItemPositionChange: 
            for line in self.lines: line.update_position()
        return super().itemChange(change, value)

class SchemaCanvas(QGraphicsView):
    def __init__(self, comms):
        super().__init__()
        self.comms = comms
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)
        self.setSceneRect(0, 0, 5000, 5000)
        
        # خلفية داكنة جداً (Deep Dark)
        self.setBackgroundBrush(QBrush(QColor("#101010")))
        
        self.table_items = {}
        self.connector_items = []
        self.setAcceptDrops(True)
        
        # إعدادات الرسم عالي الجودة
        self.setRenderHint(QPainter.Antialiasing)
        self.setRenderHint(QPainter.TextAntialiasing)
        self.setRenderHint(QPainter.SmoothPixmapTransform)

    def drawBackground(self, painter, rect):
        super().drawBackground(painter, rect)
        
        # رسم شبكة منقطة (Dot Grid) بدلاً من الخطوط
        grid_size = 25
        left = int(rect.left()) - (int(rect.left()) % grid_size)
        top = int(rect.top()) - (int(rect.top()) % grid_size)
        
        points = []
        for x in range(left, int(rect.right()), grid_size):
            for y in range(top, int(rect.bottom()), grid_size):
                points.append(QPointF(x, y))
        
        painter.setPen(QPen(QColor("#333333"), 1))
        painter.drawPoints(points)

    def dragEnterEvent(self, event):
        if event.mimeData().text() == "CREATE_TABLE": event.accept()
        else: event.ignore()
    def dragMoveEvent(self, event):
        if event.mimeData().text() == "CREATE_TABLE": event.accept()
        else: event.ignore()
    def dropEvent(self, event):
        if event.mimeData().text() == "CREATE_TABLE":
            pos = self.mapToScene(event.position().toPoint())
            self.comms.request_create_table_at.emit(pos.x(), pos.y())
            event.accept()
        else: event.ignore()

    def add_table_visual(self, name, x=100, y=100):
        item = TableItem(name, x, y, self.comms)
        # ظل ناعم جداً
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(25)
        shadow.setColor(QColor(0,0,0,180))
        shadow.setOffset(0, 5)
        item.setGraphicsEffect(shadow)
        self.scene.addItem(item); self.table_items[name] = item
    
    def remove_table_visual(self, name):
        if name in self.table_items:
            item = self.table_items[name]
            for line in item.lines[:]: self.scene.removeItem(line); 
            if item.lines: self.connector_items = [c for c in self.connector_items if c not in item.lines]
            self.scene.removeItem(item); del self.table_items[name]
    def update_table_visual(self, name, cols):
        if name in self.table_items: self.table_items[name].update_columns_visual(cols)
    def rename_table_visual(self, old_name, new_name):
        if old_name in self.table_items:
            item = self.table_items[old_name]; item.table_name = new_name; self.table_items[new_name] = item; del self.table_items[old_name]; item.update()
    def add_connector(self, from_name, to_name, rel_type):
        if from_name in self.table_items and to_name in self.table_items:
            start = self.table_items[from_name]; end = self.table_items[to_name]
            line = ConnectorLine(start, end, rel_type, self.comms)
            self.scene.addItem(line); start.lines.append(line); end.lines.append(line); self.connector_items.append(line)
    def remove_connector_visual(self, from_name, to_name):
        for line in self.connector_items:
            if line.start_item.table_name == from_name and line.end_item.table_name == to_name:
                self.scene.removeItem(line); line.start_item.lines.remove(line); line.end_item.lines.remove(line); self.connector_items.remove(line); break
"""
with open("views/canvas_view.py", "w", encoding="utf-8") as f:
    f.write(canvas_code)

# ---------------------------------------------------------
# 2. VIEW: main_window.py (ثيم جديد كلياً - Pro Dark)
# ---------------------------------------------------------
window_code = """from PySide6.QtWidgets import (QMainWindow, QVBoxLayout, QWidget, QPushButton, 
                                 QInputDialog, QHBoxLayout, QTextEdit, QTableWidget, 
                                 QTableWidgetItem, QSplitter, QLabel, QMessageBox, QDialog,
                                 QFormLayout, QComboBox, QListWidget, QLineEdit, QHeaderView, QFileDialog, QFrame)
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QKeySequence, QFont, QColor, QPalette
from .canvas_view import SchemaCanvas, Communicate, ToolboxWidget

# --- MODERN PRO THEME (ستايل CSS احترافي) ---
MODERN_THEME = \"\"\"
QMainWindow { background-color: #121212; color: #ffffff; }

/* Menu Bar */
QMenuBar { background-color: #1e1e1e; color: #cccccc; padding: 5px; border-bottom: 1px solid #333; }
QMenuBar::item { padding: 5px 10px; background: transparent; }
QMenuBar::item:selected { background-color: #333333; border-radius: 4px; color: white; }
QMenu { background-color: #1e1e1e; border: 1px solid #333; padding: 5px; }
QMenu::item { padding: 5px 20px; color: #cccccc; }
QMenu::item:selected { background-color: #094771; color: white; border-radius: 4px; }

/* Buttons */
QPushButton { 
    background-color: #2d2d30; 
    border: 1px solid #3e3e42; 
    border-radius: 6px; 
    padding: 8px 16px; 
    font-family: 'Segoe UI';
    font-weight: 600;
    color: #f0f0f0;
}
QPushButton:hover { background-color: #3e3e42; border-color: #555; }
QPushButton:pressed { background-color: #007acc; border-color: #007acc; }
QPushButton:checked { background-color: #007acc; border-color: #007acc; }

/* Inputs */
QLineEdit, QComboBox, QTextEdit { 
    background-color: #1e1e1e; 
    border: 1px solid #3e3e42; 
    border-radius: 5px; 
    padding: 6px; 
    color: #dcdcdc;
    selection-background-color: #264f78;
}
QLineEdit:focus, QTextEdit:focus { border: 1px solid #007acc; }

/* Table Results */
QTableWidget { 
    background-color: #1e1e1e; 
    gridline-color: #333; 
    border: none; 
    selection-background-color: #264f78;
}
QHeaderView::section { 
    background-color: #252526; 
    padding: 6px; 
    border: none; 
    border-bottom: 1px solid #3e3e42;
    font-weight: bold;
    color: #cccccc;
}

/* Splitter */
QSplitter::handle { background-color: #2d2d30; }

/* Labels */
QLabel { font-family: 'Segoe UI'; font-weight: 600; color: #aaaaaa; letter-spacing: 0.5px; }
\"\"\"

class DataEntryDialog(QDialog):
    def __init__(self, table_name, columns):
        super().__init__(); self.setWindowTitle(f"Insert into {table_name}"); self.resize(400, 300); self.inputs = {}
        layout = QFormLayout(self)
        for col in columns: inp = QLineEdit(); inp.setPlaceholderText(col.data_type); layout.addRow(f"{col.name}:", inp); self.inputs[col.name] = inp
        btn = QPushButton("Insert"); btn.clicked.connect(self.accept); layout.addRow(btn)
    def get_values(self): return {name: inp.text() for name, inp in self.inputs.items()}

class TableCreationDialog(QDialog):
    def __init__(self):
        super().__init__(); self.setWindowTitle("New Table"); self.resize(300, 200); layout = QFormLayout(self)
        self.name_edit = QLineEdit(); self.pk_name_edit = QLineEdit("id"); self.pk_type_combo = QComboBox(); self.pk_type_combo.addItems(["INTEGER", "VARCHAR(36)"])
        layout.addRow("Name:", self.name_edit); layout.addRow("PK:", self.pk_name_edit); layout.addRow("Type:", self.pk_type_combo)
        btn = QPushButton("Create"); btn.clicked.connect(self.accept); layout.addRow(btn)
    def get_data(self): return self.name_edit.text(), self.pk_name_edit.text(), self.pk_type_combo.currentText().split(" ")[0]

class RelationshipDialog(QDialog):
    def __init__(self, table_names):
        super().__init__(); self.setWindowTitle("Relationship"); self.resize(300, 150); layout = QFormLayout(self)
        self.src = QComboBox(); self.src.addItems(table_names); self.tgt = QComboBox(); self.tgt.addItems(table_names); self.type = QComboBox(); self.type.addItems(["1-N", "N-N"])
        layout.addRow("From:", self.src); layout.addRow("To:", self.tgt); layout.addRow("Type:", self.type)
        btn = QPushButton("Link"); btn.clicked.connect(self.accept); layout.addRow(btn)
    def get_data(self): return self.src.currentText(), self.tgt.currentText(), self.type.currentText()

class TableEditorDialog(QDialog):
    def __init__(self, table_name, columns):
        super().__init__(); self.setWindowTitle(f"Edit {table_name}"); self.resize(400, 300); self.layout = QVBoxLayout(self)
        self.name_edit = QLineEdit(table_name); self.layout.addWidget(QLabel("Name:")); self.layout.addWidget(self.name_edit)
        self.col_list = QListWidget(); 
        for col in columns: self.col_list.addItem(f"{col.name} ({col.data_type})")
        self.layout.addWidget(self.col_list)
        h = QHBoxLayout(); self.n_col = QLineEdit(); self.n_type = QComboBox(); self.n_type.addItems(["VARCHAR", "INTEGER", "TEXT", "DATE"])
        btn = QPushButton("+"); btn.clicked.connect(self.add_c); h.addWidget(self.n_col); h.addWidget(self.n_type); h.addWidget(btn); self.layout.addLayout(h)
        b_del = QPushButton("Delete Col"); b_del.clicked.connect(self.del_c); self.layout.addWidget(b_del)
        save = QPushButton("Save"); save.clicked.connect(self.accept); self.layout.addWidget(save)
        self.added_cols = []; self.deleted_cols = []
    def add_c(self): 
        if self.n_col.text(): self.added_cols.append((self.n_col.text(), self.n_type.currentText())); self.col_list.addItem(f"{self.n_col.text()}"); self.n_col.clear()
    def del_c(self): 
        if self.col_list.currentItem(): self.deleted_cols.append(self.col_list.currentItem().text().split(" ")[0]); self.col_list.takeItem(self.col_list.currentRow())

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ultimate DB Designer v8.0 (Modern UI)") 
        self.resize(1300, 850)
        self.setStyleSheet(MODERN_THEME) # تطبيق الثيم الجديد
        self.comms = Communicate()

        # --- MENU BAR ---
        menu_bar = self.menuBar()
        file_menu = menu_bar.addMenu("File")
        self.act_new = QAction("New Project", self); self.act_new.setShortcut(QKeySequence.New)
        self.act_open = QAction("Open Project...", self); self.act_open.setShortcut(QKeySequence.Open)
        self.act_save = QAction("Save Project As...", self); self.act_save.setShortcut(QKeySequence.Save)
        self.act_exit = QAction("Exit", self); self.act_exit.triggered.connect(self.close)
        file_menu.addAction(self.act_new); file_menu.addAction(self.act_open); file_menu.addAction(self.act_save); file_menu.addSeparator(); file_menu.addAction(self.act_exit)

        central = QWidget(); self.setCentralWidget(central); main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0); main_layout.setSpacing(0) # إلغاء الهوامش

        # --- Left Sidebar (Tools) ---
        tools_widget = QWidget()
        tools_widget.setStyleSheet("background-color: #252526; border-right: 1px solid #333;")
        tools_widget.setFixedWidth(200)
        tools_layout = QVBoxLayout(tools_widget)
        tools_layout.setContentsMargins(10, 20, 10, 20)
        
        self.btn_toggle_toolbox = QPushButton("📦 Toolbox"); self.btn_toggle_toolbox.setCheckable(True); self.btn_toggle_toolbox.clicked.connect(self.toggle_toolbox)
        
        self.btn_add_table = QPushButton("➕ Table"); self.btn_add_rel = QPushButton("🔗 Connect")
        self.btn_gen_sql = QPushButton("📜 Generate SQL"); self.btn_exec_sql = QPushButton("▶ Run SQL")
        
        tools_layout.addWidget(QLabel("VISUAL TOOLS"))
        tools_layout.addWidget(self.btn_toggle_toolbox)
        tools_layout.addWidget(self.btn_add_table)
        tools_layout.addWidget(self.btn_add_rel)
        tools_layout.addSpacing(30)
        tools_layout.addWidget(QLabel("SQL ENGINE"))
        tools_layout.addWidget(self.btn_gen_sql)
        tools_layout.addWidget(self.btn_exec_sql)
        tools_layout.addStretch()

        self.toolbox = ToolboxWidget(); self.toolbox.setVisible(False)
        self.canvas = SchemaCanvas(self.comms)
        
        # --- Right Panel (SQL & Results) ---
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(10, 10, 10, 10)
        self.sql_display = QTextEdit()
        self.sql_display.setPlaceholderText("-- Write your SQL queries here...")
        self.sql_display.setStyleSheet("font-family: Consolas; font-size: 13px; color: #dcdcdc;")
        
        self.result_table = QTableWidget()
        right_layout.addWidget(QLabel("SQL EDITOR"))
        right_layout.addWidget(self.sql_display)
        right_layout.addWidget(QLabel("QUERY RESULTS"))
        right_layout.addWidget(self.result_table)

        # Splitter Layout
        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(tools_widget)
        splitter.addWidget(self.toolbox)
        splitter.addWidget(self.canvas)
        splitter.addWidget(right_panel)
        splitter.setStretchFactor(2, 5) # Canvas takes most space

        main_layout.addWidget(splitter)

    def toggle_toolbox(self):
        v = self.btn_toggle_toolbox.isChecked(); self.toolbox.setVisible(v)
        if v: self.toolbox.setMaximumWidth(160)
    def display_results(self, columns, rows):
        self.result_table.clear(); self.result_table.setColumnCount(len(columns)); self.result_table.setHorizontalHeaderLabels(columns); self.result_table.setRowCount(len(rows))
        self.result_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        for r, row in enumerate(rows):
            for c, data in enumerate(row): self.result_table.setItem(r, c, QTableWidgetItem(str(data)))
"""
with open("views/main_window.py", "w", encoding="utf-8") as f: f.write(window_code)

print("✅ تم تحديث الواجهة إلى التصميم الحديث (v8.0)!")
print("✨ المميزات الجديدة: ثيم داكن احترافي، شبكة منقطة، جداول عصرية، أيقونات وأزرار محسنة.")
print("👉 شغل البرنامج الآن: python main.py")