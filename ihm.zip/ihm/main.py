import sys
from PySide6.QtWidgets import QApplication
from models.database_model import SchemaModel
from views.main_window import MainWindow
from controllers.main_controller import MainController

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    model = SchemaModel()
    view = MainWindow()
    controller = MainController(model, view)
    
    view.show()
    sys.exit(app.exec())
