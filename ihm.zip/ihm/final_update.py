import os

# ---------------------------------------------------------
# 1. VIEW: canvas_view.py (الإصدار المصحح والخالي من الأخطاء)
# ---------------------------------------------------------
canvas_code = """from PySide6.QtWidgets import (QGraphicsScene, QGraphicsView, QGraphicsItem, QMenu, QGraphicsLineItem, 
                               QGraphicsDropShadowEffect, QListWidget, QListWidgetItem, QGraphicsTextItem)
from PySide6.QtCore import Qt, QPointF, Signal, QObject, QLineF, QRectF, QMimeData, QSize
from PySide6.QtGui import QBrush, QPen, QColor, QFont, QPainter, QLinearGradient, QPainterPath, QDrag

class Communicate(QObject):
    request_edit_table = Signal(str)
    request_delete_table = Signal(str)
    request_delete_rel = Signal(str, str)
    request_insert_data = Signal(str)
    request_create_table_at = Signal(float, float)

class ToolboxWidget(QListWidget):
    def __init__(self):
        super().__init__()
        self.setDragEnabled(True)
        self.setViewMode(QListWidget.IconMode)
        self.setIconSize(QSize(40, 40)) # FIXED
        self.setSpacing(10)
        self.setAcceptDrops(False)
        self.setStyleSheet("QListWidget { background-color: #2b2b2b; border: 1px solid #444; color: white; } QListWidget::item:hover { background-color: #505050; }")

        item = QListWidgetItem("New Table")
        item.setTextAlignment(Qt.AlignCenter)
        font = QFont(); font.setBold(True); item.setFont(font)
        item.setToolTip("Drag this to the canvas")
        self.addItem(item)

    def startDrag(self, supportedActions):
        item = self.currentItem()
        mime_data = QMimeData()
        mime_data.setText("CREATE_TABLE")
        drag = QDrag(self)
        drag.setMimeData(mime_data)
        drag.exec(supportedActions)

class ConnectorLine(QGraphicsLineItem):
    def __init__(self, start_item, end_item, rel_type, comms):
        super().__init__()
        self.start_item = start_item
        self.end_item = end_item
        self.rel_type = rel_type
        self.comms = comms
        self.setZValue(-2) 
        self.setFlag(QGraphicsItem.ItemIsSelectable)
        pen = QPen(QColor("#a0a0a0"), 2); pen.setStyle(Qt.DashLine)
        self.setPen(pen)
        self.start_label = QGraphicsTextItem("", self); self.end_label = QGraphicsTextItem("", self)
        self.setup_labels(); self.update_position()
    def setup_labels(self):
        font = QFont("Segoe UI", 10, QFont.Bold)
        self.start_label.setFont(font); self.end_label.setFont(font)
        self.start_label.setDefaultTextColor(QColor("#ff5555")); self.end_label.setDefaultTextColor(QColor("#ff5555"))
        if self.rel_type == "1-N": self.start_label.setPlainText("N"); self.end_label.setPlainText("1")
        elif self.rel_type == "N-N": self.start_label.setPlainText("N"); self.end_label.setPlainText("N") 
    def update_position(self):
        start_pos = self.start_item.scenePos() + QPointF(self.start_item.boundingRect().width()/2, self.start_item.boundingRect().height()/2)
        end_pos = self.end_item.scenePos() + QPointF(self.end_item.boundingRect().width()/2, self.end_item.boundingRect().height()/2)
        line = QLineF(start_pos, end_pos); self.setLine(line)
        self.start_label.setPos(line.pointAt(0.15)); self.end_label.setPos(line.pointAt(0.85))
    def contextMenuEvent(self, event):
        menu = QMenu()
        menu.setStyleSheet("QMenu { background-color: #333; color: white; }")
        del_action = menu.addAction("❌ Delete Connection")
        if menu.exec(event.screenPos()) == del_action: self.comms.request_delete_rel.emit(self.start_item.table_name, self.end_item.table_name)

class TableItem(QGraphicsItem):
    def __init__(self, table_name, x, y, comms):
        super().__init__()
        self.setPos(x, y); self.comms = comms; self.table_name = table_name
        self.columns_list = []; self.lines = []
        self.setFlags(QGraphicsItem.ItemIsMovable | QGraphicsItem.ItemIsSelectable | QGraphicsItem.ItemSendsGeometryChanges)
        self.width = 180; self.header_height = 35; self.row_height = 20; self.height = 100 
    def boundingRect(self): return QRectF(0, 0, self.width, self.height)
    def paint(self, painter, option, widget):
        path = QPainterPath(); path.addRoundedRect(self.boundingRect(), 10, 10)
        painter.setRenderHint(QPainter.Antialiasing); painter.fillPath(path, QBrush(QColor("#2d2d2d"))); painter.setPen(QPen(QColor("#444"), 1)); painter.drawPath(path)
        header_path = QPainterPath(); header_path.addRoundedRect(0, 0, self.width, self.header_height, 10, 10)
        painter.save(); painter.setClipRect(0, 0, self.width, self.header_height)
        grad = QLinearGradient(0, 0, self.width, self.header_height); grad.setColorAt(0, QColor("#6a11cb")); grad.setColorAt(1, QColor("#2575fc")) 
        painter.fillPath(header_path, QBrush(grad)); painter.restore()
        painter.setPen(Qt.white); painter.setFont(QFont("Segoe UI", 11, QFont.Bold)); painter.drawText(QRectF(0, 0, self.width, self.header_height), Qt.AlignCenter, self.table_name)
        y_offset = self.header_height + 20; painter.setFont(QFont("Consolas", 9))
        for col in self.columns_list:
            icon = "🔑" if col.is_pk else "🔹"; color = QColor("#ffeb3b") if col.is_pk else QColor("#a0a0a0")
            painter.setPen(color); painter.drawText(10, y_offset, icon)
            painter.setPen(QColor("#e0e0e0")); painter.drawText(35, y_offset, col.name)
            painter.setPen(QColor("#808080")); painter.drawText(self.width - 80, y_offset, col.data_type)
            y_offset += self.row_height
    def update_columns_visual(self, columns_list):
        self.columns_list = columns_list; self.height = self.header_height + 25 + (len(columns_list) * self.row_height); self.update() 
    def mouseDoubleClickEvent(self, event): self.comms.request_edit_table.emit(self.table_name); super().mouseDoubleClickEvent(event)
    def contextMenuEvent(self, event):
        menu = QMenu(); menu.setStyleSheet("QMenu { background-color: #2b2b2b; color: #ffffff; }")
        edit = menu.addAction("✏️ Edit"); data = menu.addAction("📝 Insert Data"); menu.addSeparator(); rm = menu.addAction("🗑️ Delete")
        sel = menu.exec(event.screenPos())
        if sel == edit: self.comms.request_edit_table.emit(self.table_name)
        elif sel == rm: self.comms.request_delete_table.emit(self.table_name)
        elif sel == data: self.comms.request_insert_data.emit(self.table_name)
    def itemChange(self, change, value):
        if change == QGraphicsItem.ItemPositionChange: 
            for line in self.lines: line.update_position()
        return super().itemChange(change, value)

class SchemaCanvas(QGraphicsView):
    def __init__(self, comms):
        super().__init__()
        self.comms = comms; self.scene = QGraphicsScene(self); self.setScene(self.scene); self.setSceneRect(0, 0, 4000, 4000)
        self.setBackgroundBrush(QBrush(QColor("#181818"))); self.table_items = {}; self.connector_items = []
        self.setAcceptDrops(True)

    def drawBackground(self, painter, rect):
        super().drawBackground(painter, rect); grid_size = 40
        left = int(rect.left()) - (int(rect.left()) % grid_size); top = int(rect.top()) - (int(rect.top()) % grid_size)
        lines = []
        for x in range(left, int(rect.right()), grid_size): lines.append(QLineF(x, rect.top(), x, rect.bottom()))
        for y in range(top, int(rect.bottom()), grid_size): lines.append(QLineF(rect.left(), y, rect.right(), y))
        painter.setPen(QPen(QColor("#222222"), 1)); painter.drawLines(lines)

    def dragEnterEvent(self, event):
        if event.mimeData().text() == "CREATE_TABLE": event.accept()
        else: event.ignore()
    def dragMoveEvent(self, event):
        if event.mimeData().text() == "CREATE_TABLE": event.accept()
        else: event.ignore()
    def dropEvent(self, event):
        if event.mimeData().text() == "CREATE_TABLE":
            pos = self.mapToScene(event.position().toPoint())
            self.comms.request_create_table_at.emit(pos.x(), pos.y())
            event.accept()
        else: event.ignore()

    def add_table_visual(self, name, x=100, y=100):
        item = TableItem(name, x, y, self.comms); shadow = QGraphicsDropShadowEffect(); shadow.setBlurRadius(20); shadow.setColor(QColor(0,0,0,150)); shadow.setOffset(5,5); item.setGraphicsEffect(shadow)
        self.scene.addItem(item); self.table_items[name] = item
    def remove_table_visual(self, name):
        if name in self.table_items:
            item = self.table_items[name]
            for line in item.lines[:]: self.scene.removeItem(line); 
            if item.lines: self.connector_items = [c for c in self.connector_items if c not in item.lines]
            self.scene.removeItem(item); del self.table_items[name]
    def update_table_visual(self, name, cols):
        if name in self.table_items: self.table_items[name].update_columns_visual(cols)
    def rename_table_visual(self, old_name, new_name):
        if old_name in self.table_items:
            item = self.table_items[old_name]; item.table_name = new_name; self.table_items[new_name] = item; del self.table_items[old_name]; item.update()
    def add_connector(self, from_name, to_name, rel_type):
        if from_name in self.table_items and to_name in self.table_items:
            start = self.table_items[from_name]; end = self.table_items[to_name]
            line = ConnectorLine(start, end, rel_type, self.comms)
            self.scene.addItem(line); start.lines.append(line); end.lines.append(line); self.connector_items.append(line)
    def remove_connector_visual(self, from_name, to_name):
        for line in self.connector_items:
            if line.start_item.table_name == from_name and line.end_item.table_name == to_name:
                self.scene.removeItem(line); line.start_item.lines.remove(line); line.end_item.lines.remove(line); self.connector_items.remove(line); break
"""
with open("views/canvas_view.py", "w", encoding="utf-8") as f: f.write(canvas_code)

# ---------------------------------------------------------
# 2. VIEW: main_window.py (مع زر Visual Mode)
# ---------------------------------------------------------
window_code = """from PySide6.QtWidgets import (QMainWindow, QVBoxLayout, QWidget, QPushButton, 
                                 QInputDialog, QHBoxLayout, QTextEdit, QTableWidget, 
                                 QTableWidgetItem, QSplitter, QLabel, QMessageBox, QDialog,
                                 QFormLayout, QComboBox, QListWidget, QLineEdit, QHeaderView)
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon, QFont
from .canvas_view import SchemaCanvas, Communicate, ToolboxWidget

DARK_THEME = \"\"\"
QMainWindow { background-color: #1e1e1e; color: #ffffff; }
QWidget { color: #f0f0f0; font-family: 'Segoe UI'; font-size: 14px; }
QPushButton { background-color: #3a3a3a; border: 1px solid #555; border-radius: 6px; padding: 8px 15px; font-weight: bold; }
QPushButton:hover { background-color: #505050; border-color: #777; }
QPushButton:pressed { background-color: #2575fc; color: white; border: none; }
QLineEdit, QComboBox, QTextEdit { background-color: #2b2b2b; border: 1px solid #444; border-radius: 4px; padding: 5px; color: white; }
QTableWidget { background-color: #2b2b2b; gridline-color: #444; border: none; selection-background-color: #2575fc; }
QHeaderView::section { background-color: #333; padding: 4px; border: 1px solid #444; }
QLabel { font-weight: bold; color: #ccc; }
QSplitter::handle { background-color: #333; }
\"\"\"

class DataEntryDialog(QDialog):
    def __init__(self, table_name, columns):
        super().__init__(); self.setWindowTitle(f"Insert into {table_name}"); self.resize(400, 300); self.inputs = {}
        layout = QFormLayout(self)
        for col in columns: inp = QLineEdit(); inp.setPlaceholderText(col.data_type); layout.addRow(f"{col.name}:", inp); self.inputs[col.name] = inp
        btn = QPushButton("Insert"); btn.clicked.connect(self.accept); layout.addRow(btn)
    def get_values(self): return {name: inp.text() for name, inp in self.inputs.items()}

class TableCreationDialog(QDialog):
    def __init__(self):
        super().__init__(); self.setWindowTitle("New Table"); self.resize(300, 200); layout = QFormLayout(self)
        self.name_edit = QLineEdit(); self.pk_name_edit = QLineEdit("id"); self.pk_type_combo = QComboBox(); self.pk_type_combo.addItems(["INTEGER", "VARCHAR(36)"])
        layout.addRow("Name:", self.name_edit); layout.addRow("PK:", self.pk_name_edit); layout.addRow("Type:", self.pk_type_combo)
        btn = QPushButton("Create"); btn.clicked.connect(self.accept); layout.addRow(btn)
    def get_data(self): return self.name_edit.text(), self.pk_name_edit.text(), self.pk_type_combo.currentText().split(" ")[0]

class RelationshipDialog(QDialog):
    def __init__(self, table_names):
        super().__init__(); self.setWindowTitle("Relationship"); self.resize(300, 150); layout = QFormLayout(self)
        self.src = QComboBox(); self.src.addItems(table_names); self.tgt = QComboBox(); self.tgt.addItems(table_names); self.type = QComboBox(); self.type.addItems(["1-N", "N-N"])
        layout.addRow("From:", self.src); layout.addRow("To:", self.tgt); layout.addRow("Type:", self.type)
        btn = QPushButton("Link"); btn.clicked.connect(self.accept); layout.addRow(btn)
    def get_data(self): return self.src.currentText(), self.tgt.currentText(), self.type.currentText()

class TableEditorDialog(QDialog):
    def __init__(self, table_name, columns):
        super().__init__(); self.setWindowTitle(f"Edit {table_name}"); self.resize(400, 300); self.layout = QVBoxLayout(self)
        self.name_edit = QLineEdit(table_name); self.layout.addWidget(QLabel("Name:")); self.layout.addWidget(self.name_edit)
        self.col_list = QListWidget(); 
        for col in columns: self.col_list.addItem(f"{col.name} ({col.data_type})")
        self.layout.addWidget(self.col_list)
        h = QHBoxLayout(); self.n_col = QLineEdit(); self.n_type = QComboBox(); self.n_type.addItems(["VARCHAR", "INTEGER", "TEXT", "DATE"])
        btn = QPushButton("+"); btn.clicked.connect(self.add_c); h.addWidget(self.n_col); h.addWidget(self.n_type); h.addWidget(btn); self.layout.addLayout(h)
        b_del = QPushButton("Delete Col"); b_del.clicked.connect(self.del_c); self.layout.addWidget(b_del)
        save = QPushButton("Save"); save.clicked.connect(self.accept); self.layout.addWidget(save)
        self.added_cols = []; self.deleted_cols = []
    def add_c(self): 
        if self.n_col.text(): self.added_cols.append((self.n_col.text(), self.n_type.currentText())); self.col_list.addItem(f"{self.n_col.text()}"); self.n_col.clear()
    def del_c(self): 
        if self.col_list.currentItem(): self.deleted_cols.append(self.col_list.currentItem().text().split(" ")[0]); self.col_list.takeItem(self.col_list.currentRow())

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); 
        # --- تحديث العنوان للتأكد من نجاح التحديث ---
        self.setWindowTitle("Ultimate DB Designer v6.7 (With Toolbox)"); 
        self.resize(1300, 850); self.setStyleSheet(DARK_THEME)
        self.comms = Communicate()
        central = QWidget(); self.setCentralWidget(central); main_layout = QHBoxLayout(central)
        
        tools = QVBoxLayout()
        # --- الزر الجديد هنا ---
        self.btn_toggle_toolbox = QPushButton("🎨 Visual Mode"); self.btn_toggle_toolbox.setCheckable(True); self.btn_toggle_toolbox.clicked.connect(self.toggle_toolbox)
        
        self.btn_add_table = QPushButton("➕ Table"); self.btn_add_rel = QPushButton("🔗 Connect"); self.btn_gen_sql = QPushButton("📄 SQL Code"); self.btn_exec_sql = QPushButton("▶ Run SQL")
        tools.addWidget(QLabel("DESIGNER")); tools.addWidget(self.btn_toggle_toolbox); tools.addWidget(self.btn_add_table); tools.addWidget(self.btn_add_rel)
        tools.addSpacing(20); tools.addWidget(QLabel("ENGINE")); tools.addWidget(self.btn_gen_sql); tools.addWidget(self.btn_exec_sql); tools.addStretch()

        self.toolbox = ToolboxWidget(); self.toolbox.setVisible(False)
        self.canvas = SchemaCanvas(self.comms)
        
        right = QWidget(); r_layout = QVBoxLayout(right)
        self.sql_display = QTextEdit(); self.result_table = QTableWidget()
        r_layout.addWidget(QLabel("SQL:")); r_layout.addWidget(self.sql_display); r_layout.addWidget(QLabel("Result:")); r_layout.addWidget(self.result_table)

        splitter = QSplitter(Qt.Horizontal); w = QWidget(); w.setLayout(tools)
        splitter.addWidget(w); splitter.addWidget(self.toolbox); splitter.addWidget(self.canvas); splitter.addWidget(right)
        splitter.setStretchFactor(2, 4); main_layout.addWidget(splitter)

    def toggle_toolbox(self):
        v = self.btn_toggle_toolbox.isChecked(); self.toolbox.setVisible(v)
        if v: self.toolbox.setMaximumWidth(150)
    def display_results(self, columns, rows):
        self.result_table.clear(); self.result_table.setColumnCount(len(columns)); self.result_table.setHorizontalHeaderLabels(columns); self.result_table.setRowCount(len(rows))
        self.result_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        for r, row in enumerate(rows):
            for c, data in enumerate(row): self.result_table.setItem(r, c, QTableWidgetItem(str(data)))
"""
with open("views/main_window.py", "w", encoding="utf-8") as f: f.write(window_code)

# ---------------------------------------------------------
# 3. CONTROLLER: main_controller.py
# ---------------------------------------------------------
ctrl_code = """from views.main_window import TableEditorDialog, RelationshipDialog, TableCreationDialog, DataEntryDialog
from PySide6.QtWidgets import QMessageBox

class MainController:
    def __init__(self, model, view):
        self.model = model; self.view = view
        self.view.btn_add_table.clicked.connect(self.add_table)
        self.view.btn_add_rel.clicked.connect(self.open_relationship_dialog)
        self.view.btn_gen_sql.clicked.connect(self.generate_sql)
        self.view.btn_exec_sql.clicked.connect(self.execute_sql)
        self.view.comms.request_edit_table.connect(self.open_edit_table_dialog)
        self.view.comms.request_delete_table.connect(self.delete_table)
        self.view.comms.request_delete_rel.connect(self.delete_relationship)
        self.view.comms.request_insert_data.connect(self.open_insert_data_dialog)
        self.view.comms.request_create_table_at.connect(self.create_table_at_drop) # NEW

    def create_table_at_drop(self, x, y):
        dialog = TableCreationDialog()
        if dialog.exec():
            name, pk, pkt = dialog.get_data()
            if name: 
                try: 
                    self.model.add_table(name, pk, pkt, x, y)
                    self.view.canvas.add_table_visual(name, x, y)
                    self.view.canvas.update_table_visual(name, self.model.tables[name].columns)
                except Exception as e: QMessageBox.critical(self.view, "Error", str(e))

    def add_table(self):
        dialog = TableCreationDialog()
        if dialog.exec():
            name, pk, pkt = dialog.get_data()
            if name:
                try:
                    self.model.add_table(name, pk, pkt, 100, 100)
                    self.view.canvas.add_table_visual(name, 100, 100)
                    self.view.canvas.update_table_visual(name, self.model.tables[name].columns)
                except Exception as e: QMessageBox.critical(self.view, "Error", str(e))

    def open_relationship_dialog(self):
        tables = list(self.model.tables.keys())
        if len(tables) < 2: QMessageBox.warning(self.view, "Warning", "Need 2 tables!"); return
        dialog = RelationshipDialog(tables)
        if dialog.exec():
            src, tgt, rtype = dialog.get_data()
            if src == tgt: return
            if rtype == "N-N":
                mid = f"{src}_{tgt}"
                if mid in self.model.tables: mid = f"{tgt}_{src}"
                if mid in self.model.tables: return
                try:
                    s_item, t_item = self.view.canvas.table_items[src], self.view.canvas.table_items[tgt]
                    mx, my = (s_item.x()+t_item.x())/2, (s_item.y()+t_item.y())/2 + 50
                    self.model.add_table(mid, "id", "INTEGER", mx, my)
                    self.view.canvas.add_table_visual(mid, mx, my)
                    self.model.add_column(mid, f"{src}_id", "INTEGER"); self.model.add_column(mid, f"{tgt}_id", "INTEGER")
                    self.view.canvas.update_table_visual(mid, self.model.tables[mid].columns)
                    self.model.add_relationship(mid, src, "1-N"); self.view.canvas.add_connector(mid, src, "1-N")
                    self.model.add_relationship(mid, tgt, "1-N"); self.view.canvas.add_connector(mid, tgt, "1-N")
                except: pass
            else:
                self.model.add_relationship(src, tgt, rtype)
                self.view.canvas.add_connector(src, tgt, rtype)
                self.view.canvas.update_table_visual(src, self.model.tables[src].columns)

    def delete_relationship(self, f, t):
        self.model.delete_relationship(f, t); self.view.canvas.remove_connector_visual(f, t)
        self.view.canvas.update_table_visual(f, self.model.tables[f].columns)
        if "_" in f and t in f: self.delete_table(f)

    def open_edit_table_dialog(self, name):
        if name not in self.model.tables: return
        dialog = TableEditorDialog(name, self.model.tables[name].columns)
        if dialog.exec():
            new_name = dialog.name_edit.text()
            if new_name != name:
                try: self.model.rename_table(name, new_name); self.view.canvas.rename_table_visual(name, new_name); name = new_name
                except: pass
            for c, t in dialog.added_cols: self.model.add_column(name, c, t)
            for c in dialog.deleted_cols: self.model.delete_column(name, c)
            self.view.canvas.update_table_visual(name, self.model.tables[name].columns)

    def open_insert_data_dialog(self, name):
        dialog = DataEntryDialog(name, self.model.tables[name].columns)
        if dialog.exec():
            v = dialog.get_values(); c = ", ".join(v.keys()); val = ", ".join([f"'{x}'" for x in v.values()])
            msg, res = self.model.execute_query(f"INSERT INTO {name} ({c}) VALUES ({val});")
            if msg[0] == "Error": QMessageBox.critical(self.view, "Error", str(res[0]))
            else: QMessageBox.information(self.view, "Success", "Done!")

    def delete_table(self, name):
        self.model.delete_table(name); self.view.canvas.remove_table_visual(name)

    def generate_sql(self): self.view.sql_display.setText(self.model.generate_sql())

    def execute_sql(self):
        q = self.view.sql_display.toPlainText().strip(); 
        if not q: return
        if q.upper().startswith("CREATE TABLE"):
            try: 
                nm = self.model.parse_create_table_sql(q)
                if nm: self.view.canvas.add_table_visual(nm, 50, 50); self.view.canvas.update_table_visual(nm, self.model.tables[nm].columns)
            except: pass
        c, r = self.model.execute_query(q)
        self.view.display_results(c, r)
"""
with open("controllers/main_controller.py", "w", encoding="utf-8") as f: f.write(ctrl_code)

print("✅ تم التحديث الشامل (الواجهة + الرسم + المتحكم)!")
print("👉 الآن شغل البرنامج: python main.py")