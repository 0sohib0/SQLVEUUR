import os

# 1. إنشاء المجلدات
os.makedirs("models", exist_ok=True)
os.makedirs("views", exist_ok=True)
os.makedirs("controllers", exist_ok=True)
open("models/__init__.py", "w").close()
open("views/__init__.py", "w").close()
open("controllers/__init__.py", "w").close()

# ---------------------------------------------------------
# 2. MODEL: database_model.py (المنطق وقواعد البيانات)
# ---------------------------------------------------------
model_code = """from dataclasses import dataclass, field
from typing import List, Optional
import sqlite3

@dataclass
class Column:
    name: str
    data_type: str
    is_pk: bool = False

@dataclass
class Relationship:
    from_table: str
    to_table: str
    rel_type: str = "1-N"  # Or N-N

@dataclass
class Table:
    name: str
    x: float = 0.0
    y: float = 0.0
    columns: List[Column] = field(default_factory=list)

class SchemaModel:
    def __init__(self):
        self.tables = {}
        self.relationships = []

    def add_table(self, name, x=0, y=0):
        if name in self.tables:
            raise ValueError("Table already exists")
        new_table = Table(name=name, x=x, y=y)
        # Add default ID column
        new_table.columns.append(Column("id", "INTEGER", True))
        self.tables[name] = new_table
        return new_table

    def delete_table(self, name):
        if name in self.tables:
            del self.tables[name]
            # Remove related relationships
            self.relationships = [r for r in self.relationships if r.from_table != name and r.to_table != name]

    def add_column(self, table_name, col_name, col_type, is_pk=False):
        if table_name in self.tables:
            self.tables[table_name].columns.append(Column(col_name, col_type, is_pk))

    def add_relationship(self, from_tbl, to_tbl, rel_type="1-N"):
        # Check duplicates
        for r in self.relationships:
            if r.from_table == from_tbl and r.to_table == to_tbl:
                return
        self.relationships.append(Relationship(from_tbl, to_tbl, rel_type))
        # Add Foreign Key column automatically
        fk_name = f"{to_tbl.lower()}_id"
        self.add_column(from_tbl, fk_name, "INTEGER", False)

    def generate_sql(self):
        sql_stmts = []
        for table in self.tables.values():
            cols_sql = []
            for col in table.columns:
                stmt = f"{col.name} {col.data_type}"
                if col.is_pk:
                    stmt += " PRIMARY KEY"
                cols_sql.append(stmt)
            
            # Handle Foreign Keys based on relationships
            for rel in self.relationships:
                if rel.from_table == table.name:
                    fk_col = f"{rel.to_table.lower()}_id"
                    cols_sql.append(f"FOREIGN KEY({fk_col}) REFERENCES {rel.to_table}(id)")

            sql_stmts.append(f"CREATE TABLE {table.name} (\\n  " + ',\\n  '.join(cols_sql) + "\\n);")
        return "\\n\\n".join(sql_stmts)

    def execute_query(self, query):
        # Create a temporary in-memory database to test the query
        con = sqlite3.connect(":memory:")
        cur = con.cursor()
        
        # First, build the schema in this temp DB
        full_schema = self.generate_sql()
        try:
            if full_schema.strip():
                cur.executescript(full_schema)
            
            # Now execute the user query
            cur.execute(query)
            
            if query.strip().upper().startswith("SELECT"):
                columns = [description[0] for description in cur.description]
                rows = cur.fetchall()
                con.close()
                return columns, rows
            else:
                con.commit()
                con.close()
                return ["Info"], [("Query Executed Successfully",)]
        except Exception as e:
            return ["Error"], [(str(e),)]
"""
with open("models/database_model.py", "w", encoding="utf-8") as f:
    f.write(model_code)

# ---------------------------------------------------------
# 3. VIEW: canvas_view.py (الرسم المتقدم والخطوط)
# ---------------------------------------------------------
canvas_code = """from PySide6.QtWidgets import (QGraphicsScene, QGraphicsView, QGraphicsRectItem, 
                                 QGraphicsTextItem, QGraphicsItem, QMenu, QGraphicsLineItem)
from PySide6.QtCore import Qt, QPointF, Signal, QObject
from PySide6.QtGui import QBrush, QPen, QColor, QFont

class Communicate(QObject):
    # Signals to talk to Controller
    request_add_column = Signal(str)
    request_delete_table = Signal(str)
    request_connect_table = Signal(str) 

class ConnectorLine(QGraphicsLineItem):
    def __init__(self, start_item, end_item):
        super().__init__()
        self.start_item = start_item
        self.end_item = end_item
        self.setPen(QPen(Qt.black, 2))
        self.setZValue(-1) # Put lines behind tables
        self.update_position()

    def update_position(self):
        # Calculate center points
        start_pos = self.start_item.scenePos() + QPointF(self.start_item.rect().width()/2, self.start_item.rect().height()/2)
        end_pos = self.end_item.scenePos() + QPointF(self.end_item.rect().width()/2, self.end_item.rect().height()/2)
        self.setLine(start_pos.x(), start_pos.y(), end_pos.x(), end_pos.y())

class TableItem(QGraphicsRectItem):
    def __init__(self, table_name, x, y, comms):
        super().__init__(0, 0, 160, 120)
        self.setPos(x, y)
        self.comms = comms
        self.table_name = table_name
        self.columns_text = [] # list of strings
        self.lines = [] # connectors attached to this table

        # Styling
        self.setBrush(QBrush(QColor("#E0F7FA")))
        self.setPen(QPen(Qt.black, 2))
        self.setFlags(QGraphicsItem.ItemIsMovable | QGraphicsItem.ItemIsSelectable | QGraphicsItem.ItemSendsGeometryChanges)
        
        # Title
        self.title_item = QGraphicsTextItem(table_name, self)
        font = QFont()
        font.setBold(True)
        self.title_item.setFont(font)
        self.title_item.setPos(10, 5)

        # Columns Display
        self.cols_display = QGraphicsTextItem("", self)
        self.cols_display.setPos(10, 30)

    def update_columns_visual(self, columns_list):
        txt = ""
        for col in columns_list:
            pk_mark = "(PK)" if col.is_pk else ""
            txt += f"- {col.name} {col.data_type} {pk_mark}\\n"
        self.cols_display.setPlainText(txt)

    def contextMenuEvent(self, event):
        menu = QMenu()
        add_col_action = menu.addAction("Add Column")
        connect_action = menu.addAction("Connect Relationship")
        del_action = menu.addAction("Delete Table")
        
        selected = menu.exec(event.screenPos())
        
        if selected == add_col_action:
            self.comms.request_add_column.emit(self.table_name)
        elif selected == del_action:
            self.comms.request_delete_table.emit(self.table_name)
        elif selected == connect_action:
            self.comms.request_connect_table.emit(self.table_name)

    def itemChange(self, change, value):
        if change == QGraphicsItem.ItemPositionChange:
            for line in self.lines:
                line.update_position()
        return super().itemChange(change, value)

class SchemaCanvas(QGraphicsView):
    def __init__(self, comms):
        super().__init__()
        self.comms = comms
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)
        self.setSceneRect(0, 0, 3000, 3000)
        self.table_items = {} # map name -> TableItem

    def add_table_visual(self, name, x=100, y=100):
        item = TableItem(name, x, y, self.comms)
        self.scene.addItem(item)
        self.table_items[name] = item

    def remove_table_visual(self, name):
        if name in self.table_items:
            item = self.table_items[name]
            # Remove lines first
            for line in item.lines:
                self.scene.removeItem(line)
            self.scene.removeItem(item)
            del self.table_items[name]

    def update_table_columns(self, name, cols):
        if name in self.table_items:
            self.table_items[name].update_columns_visual(cols)

    def add_connector(self, from_name, to_name):
        if from_name in self.table_items and to_name in self.table_items:
            start = self.table_items[from_name]
            end = self.table_items[to_name]
            line = ConnectorLine(start, end)
            self.scene.addItem(line)
            start.lines.append(line)
            end.lines.append(line)
"""
with open("views/canvas_view.py", "w", encoding="utf-8") as f:
    f.write(canvas_code)

# ---------------------------------------------------------
# 4. VIEW: main_window.py (الواجهة الرئيسية والجدول)
# ---------------------------------------------------------
window_code = """from PySide6.QtWidgets import (QMainWindow, QVBoxLayout, QWidget, QPushButton, 
                                 QInputDialog, QHBoxLayout, QTextEdit, QTableWidget, 
                                 QTableWidgetItem, QSplitter, QLabel, QMessageBox)
from PySide6.QtCore import Qt
from .canvas_view import SchemaCanvas, Communicate

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Pro Database Designer (MVC)")
        self.resize(1200, 800)

        # Communication Bridge
        self.comms = Communicate()
        
        # Central Widget
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)

        # --- LEFT TOOLBAR ---
        tools_layout = QVBoxLayout()
        self.btn_add_table = QPushButton("Add Table")
        self.btn_gen_sql = QPushButton("Generate SQL")
        self.btn_exec_sql = QPushButton("Execute SQL")
        
        tools_layout.addWidget(QLabel("<b>Tools</b>"))
        tools_layout.addWidget(self.btn_add_table)
        tools_layout.addSpacing(20)
        tools_layout.addWidget(self.btn_gen_sql)
        tools_layout.addWidget(self.btn_exec_sql)
        tools_layout.addStretch()

        # --- CENTER: CANVAS ---
        self.canvas = SchemaCanvas(self.comms)

        # --- RIGHT: SQL EDITOR & RESULTS ---
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        right_layout.addWidget(QLabel("<b>SQL Output:</b>"))
        self.sql_display = QTextEdit()
        
        right_layout.addWidget(QLabel("<b>Query Result:</b>"))
        self.result_table = QTableWidget()
        
        right_layout.addWidget(self.sql_display)
        right_layout.addWidget(self.result_table)

        # SPLITTER for layout resizing
        splitter = QSplitter(Qt.Horizontal)
        tools_widget = QWidget()
        tools_widget.setLayout(tools_layout)
        
        splitter.addWidget(tools_widget)
        splitter.addWidget(self.canvas)
        splitter.addWidget(right_panel)
        splitter.setStretchFactor(1, 4) # Canvas is biggest

        main_layout.addWidget(splitter)

    # Helper Dialogs
    def get_text_input(self, title, label):
        text, ok = QInputDialog.getText(self, title, label)
        return text if ok and text else None
    
    def get_choice_input(self, title, label, items):
        item, ok = QInputDialog.getItem(self, title, label, items, 0, False)
        return item if ok else None

    def show_message(self, title, msg):
        QMessageBox.information(self, title, msg)

    def display_results(self, columns, rows):
        self.result_table.clear()
        self.result_table.setColumnCount(len(columns))
        self.result_table.setHorizontalHeaderLabels(columns)
        self.result_table.setRowCount(len(rows))
        
        for r_idx, row_data in enumerate(rows):
            for c_idx, data in enumerate(row_data):
                self.result_table.setItem(r_idx, c_idx, QTableWidgetItem(str(data)))
"""
with open("views/main_window.py", "w", encoding="utf-8") as f:
    f.write(window_code)

# ---------------------------------------------------------
# 5. CONTROLLER: main_controller.py (المخ)
# ---------------------------------------------------------
ctrl_code = """class MainController:
    def __init__(self, model, view):
        self.model = model
        self.view = view
        self.pending_rel_source = None # To store first table clicked for relationship

        # -- UI Connections --
        self.view.btn_add_table.clicked.connect(self.add_table)
        self.view.btn_gen_sql.clicked.connect(self.generate_sql)
        self.view.btn_exec_sql.clicked.connect(self.execute_sql)

        # -- Canvas Interactions (via Communicate) --
        self.view.comms.request_add_column.connect(self.add_column)
        self.view.comms.request_delete_table.connect(self.delete_table)
        self.view.comms.request_connect_table.connect(self.connect_table_request)

    def add_table(self):
        name = self.view.get_text_input("New Table", "Table Name:")
        if name:
            try:
                self.model.add_table(name)
                self.view.canvas.add_table_visual(name)
                # Show initial columns (ID)
                self.view.canvas.update_table_columns(name, self.model.tables[name].columns)
            except Exception as e:
                self.view.show_message("Error", str(e))

    def add_column(self, table_name):
        col_name = self.view.get_text_input("Add Column", "Column Name:")
        if not col_name: return
        
        col_type = self.view.get_choice_input("Data Type", "Select Type:", ["VARCHAR(255)", "INTEGER", "TEXT", "BOOLEAN", "DATE"])
        if not col_type: return

        self.model.add_column(table_name, col_name, col_type)
        self.view.canvas.update_table_columns(table_name, self.model.tables[table_name].columns)

    def delete_table(self, table_name):
        self.model.delete_table(table_name)
        self.view.canvas.remove_table_visual(table_name)

    def connect_table_request(self, table_name):
        if self.pending_rel_source is None:
            self.pending_rel_source = table_name
            self.view.show_message("Relationship", f"Selected {table_name}. Now right-click the target table and choose 'Connect'.")
        else:
            target = table_name
            source = self.pending_rel_source
            if source == target:
                self.view.show_message("Error", "Cannot connect table to itself")
                self.pending_rel_source = None
                return
            
            # Create Relationship in Model
            self.model.add_relationship(source, target)
            # Create Visual Line
            self.view.canvas.add_connector(source, target)
            # Update columns (Foreign Key was added)
            self.view.canvas.update_table_columns(source, self.model.tables[source].columns)
            
            self.pending_rel_source = None

    def generate_sql(self):
        sql = self.model.generate_sql()
        self.view.sql_display.setText(sql)

    def execute_sql(self):
        # Executes whatever is currently in the SQL Output box
        query = self.view.sql_display.toPlainText() # Or pop a dialog for new query
        if not query:
             query = self.view.get_text_input("Execute SQL", "Enter SQL Query (e.g. SELECT * FROM users):")
        
        if query:
            cols, rows = self.model.execute_query(query)
            self.view.display_results(cols, rows)
"""
with open("controllers/main_controller.py", "w", encoding="utf-8") as f:
    f.write(ctrl_code)

# 6. تحديث ملف main.py (نفس السابق لكن للتأكيد)
main_code = """import sys
from PySide6.QtWidgets import QApplication
from models.database_model import SchemaModel
from views.main_window import MainWindow
from controllers.main_controller import MainController

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    model = SchemaModel()
    view = MainWindow()
    controller = MainController(model, view)
    
    view.show()
    sys.exit(app.exec())
"""
with open("main.py", "w", encoding="utf-8") as f:
    f.write(main_code)

print("✅ تم تحديث المشروع بالكامل (النسخة الاحترافية)!")
print(" المميزات المضافة: إضافة أعمدة، رسم علاقات، تحديث SQL، وتنفيذ الاستعلامات.")
print("👉 شغل البرنامج الآن: python main.py")