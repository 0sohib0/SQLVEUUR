import os

# ---------------------------------------------------------
# 1. MODEL: database_model.py (إضافة الحفظ والتحميل JSON)
# ---------------------------------------------------------
model_code = """from dataclasses import dataclass, field, asdict
from typing import List
import sqlite3
import re
import json

@dataclass
class Column:
    name: str
    data_type: str
    is_pk: bool = False

@dataclass
class Relationship:
    from_table: str
    to_table: str
    rel_type: str = "1-N"

@dataclass
class Table:
    name: str
    x: float = 0.0
    y: float = 0.0
    columns: List[Column] = field(default_factory=list)

class SchemaModel:
    def __init__(self):
        self.tables = {}
        self.relationships = []
        self.db_con = sqlite3.connect(":memory:") 
        self.db_cur = self.db_con.cursor()

    def clear(self):
        self.tables = {}
        self.relationships = []
        self.db_con.close()
        self.db_con = sqlite3.connect(":memory:")
        self.db_cur = self.db_con.cursor()

    def to_dict(self):
        # تحويل البيانات إلى قاموس للحفظ
        return {
            "tables": {name: asdict(t) for name, t in self.tables.items()},
            "relationships": [asdict(r) for r in self.relationships]
        }

    def from_dict(self, data):
        # استعادة البيانات من القاموس
        self.clear()
        for t_name, t_data in data.get("tables", {}).items():
            cols = [Column(**c) for c in t_data["columns"]]
            self.tables[t_name] = Table(name=t_name, x=t_data["x"], y=t_data["y"], columns=cols)
        
        for r_data in data.get("relationships", []):
            self.relationships.append(Relationship(**r_data))

    def add_table(self, name, pk_name="id", pk_type="INTEGER", x=0, y=0):
        if name in self.tables: raise ValueError(f"Table '{name}' exists!")
        new_table = Table(name=name, x=x, y=y)
        new_table.columns.append(Column(pk_name, pk_type, True))
        self.tables[name] = new_table
        return new_table

    def parse_create_table_sql(self, sql_query):
        clean_sql = sql_query.strip()
        pattern = r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)\s*\((.+)\)"
        match = re.search(pattern, clean_sql, re.IGNORECASE | re.DOTALL)
        if match:
            tbl_name = match.group(1); cols_str = match.group(2)
            if tbl_name in self.tables: return tbl_name 
            import random
            new_tbl = Table(name=tbl_name, x=50+random.randint(0,50), y=50+random.randint(0,50))
            col_parts = [c.strip() for c in cols_str.split(',')]
            for part in col_parts:
                part = part.strip()
                if not part or any(kw in part.upper() for kw in ["FOREIGN KEY", "CONSTRAINT", "PRIMARY KEY ("]): continue
                tokens = part.split()
                if not tokens: continue
                c_name = tokens[0]; c_type = tokens[1] if len(tokens)>1 else "TEXT"
                is_pk = "PRIMARY KEY" in part.upper()
                new_tbl.columns.append(Column(c_name, c_type, is_pk))
            self.tables[tbl_name] = new_tbl
            return tbl_name
        return None

    def rename_table(self, old, new):
        if old not in self.tables: return
        self.tables[new] = self.tables.pop(old); self.tables[new].name = new
        for r in self.relationships:
            if r.from_table == old: r.from_table = new
            if r.to_table == old: r.to_table = new

    def delete_table(self, name):
        if name in self.tables:
            del self.tables[name]
            self.relationships = [r for r in self.relationships if r.from_table != name and r.to_table != name]

    def add_column(self, t_name, c_name, c_type, is_pk=False):
        if t_name in self.tables: self.tables[t_name].columns.append(Column(c_name, c_type, is_pk))

    def delete_column(self, t_name, c_name):
        if t_name in self.tables: self.tables[t_name].columns = [c for c in self.tables[t_name].columns if c.name != c_name]

    def add_relationship(self, f, t, r_type="1-N"):
        for r in self.relationships:
            if r.from_table == f and r.to_table == t: return
        self.relationships.append(Relationship(f, t, r_type))
        if r_type == "1-N": self.add_column(f, f"{t.lower()}_id", "INTEGER", False)

    def delete_relationship(self, f, t):
        rel = next((r for r in self.relationships if r.from_table == f and r.to_table == t), None)
        if rel:
            self.relationships.remove(rel)
            if rel.rel_type == "1-N": self.delete_column(f, f"{t.lower()}_id")

    def generate_sql(self):
        sql = []
        for t in self.tables.values():
            cols = [f"{c.name} {c.data_type}" + (" PRIMARY KEY" if c.is_pk else "") for c in t.columns]
            for r in self.relationships:
                if r.from_table == t.name:
                    fk = f"{r.to_table.lower()}_id"
                    if any(c.name == fk for c in t.columns): cols.append(f"FOREIGN KEY({fk}) REFERENCES {r.to_table}(id)")
            sql.append(f"CREATE TABLE IF NOT EXISTS {t.name} (\\n  " + ',\\n  '.join(cols) + "\\n);")
        return "\\n\\n".join(sql)

    def execute_query(self, query):
        try:
            full_schema = self.generate_sql()
            if full_schema.strip(): 
                try: self.db_cur.executescript(full_schema)
                except: pass
            self.db_cur.execute(query)
            if query.strip().upper().startswith("SELECT"): return [d[0] for d in self.db_cur.description], self.db_cur.fetchall()
            else: self.db_con.commit(); return ["Info"], [("Success",)]
        except Exception as e: return ["Error"], [(str(e),)]
"""
with open("models/database_model.py", "w", encoding="utf-8") as f: f.write(model_code)

# ---------------------------------------------------------
# 2. VIEW: main_window.py (إضافة القوائم File Menus)
# ---------------------------------------------------------
window_code = """from PySide6.QtWidgets import (QMainWindow, QVBoxLayout, QWidget, QPushButton, 
                                 QInputDialog, QHBoxLayout, QTextEdit, QTableWidget, 
                                 QTableWidgetItem, QSplitter, QLabel, QMessageBox, QDialog,
                                 QFormLayout, QComboBox, QListWidget, QLineEdit, QHeaderView, QFileDialog) # Added QFileDialog
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QKeySequence # Added Actions
from .canvas_view import SchemaCanvas, Communicate, ToolboxWidget

DARK_THEME = \"\"\"
QMainWindow { background-color: #1e1e1e; color: #ffffff; }
QMenuBar { background-color: #2d2d2d; color: white; }
QMenuBar::item:selected { background-color: #3d3d3d; }
QMenu { background-color: #2d2d2d; color: white; border: 1px solid #444; }
QMenu::item:selected { background-color: #2575fc; }
QWidget { color: #f0f0f0; font-family: 'Segoe UI'; font-size: 14px; }
QPushButton { background-color: #3a3a3a; border: 1px solid #555; border-radius: 6px; padding: 8px 15px; font-weight: bold; }
QPushButton:hover { background-color: #505050; border-color: #777; }
QPushButton:pressed { background-color: #2575fc; color: white; border: none; }
QLineEdit, QComboBox, QTextEdit { background-color: #2b2b2b; border: 1px solid #444; border-radius: 4px; padding: 5px; color: white; }
QTableWidget { background-color: #2b2b2b; gridline-color: #444; border: none; selection-background-color: #2575fc; }
QHeaderView::section { background-color: #333; padding: 4px; border: 1px solid #444; }
QLabel { font-weight: bold; color: #ccc; }
QSplitter::handle { background-color: #333; }
\"\"\"

class DataEntryDialog(QDialog):
    def __init__(self, table_name, columns):
        super().__init__(); self.setWindowTitle(f"Insert into {table_name}"); self.resize(400, 300); self.inputs = {}
        layout = QFormLayout(self)
        for col in columns: inp = QLineEdit(); inp.setPlaceholderText(col.data_type); layout.addRow(f"{col.name}:", inp); self.inputs[col.name] = inp
        btn = QPushButton("Insert"); btn.clicked.connect(self.accept); layout.addRow(btn)
    def get_values(self): return {name: inp.text() for name, inp in self.inputs.items()}

class TableCreationDialog(QDialog):
    def __init__(self):
        super().__init__(); self.setWindowTitle("New Table"); self.resize(300, 200); layout = QFormLayout(self)
        self.name_edit = QLineEdit(); self.pk_name_edit = QLineEdit("id"); self.pk_type_combo = QComboBox(); self.pk_type_combo.addItems(["INTEGER", "VARCHAR(36)"])
        layout.addRow("Name:", self.name_edit); layout.addRow("PK:", self.pk_name_edit); layout.addRow("Type:", self.pk_type_combo)
        btn = QPushButton("Create"); btn.clicked.connect(self.accept); layout.addRow(btn)
    def get_data(self): return self.name_edit.text(), self.pk_name_edit.text(), self.pk_type_combo.currentText().split(" ")[0]

class RelationshipDialog(QDialog):
    def __init__(self, table_names):
        super().__init__(); self.setWindowTitle("Relationship"); self.resize(300, 150); layout = QFormLayout(self)
        self.src = QComboBox(); self.src.addItems(table_names); self.tgt = QComboBox(); self.tgt.addItems(table_names); self.type = QComboBox(); self.type.addItems(["1-N", "N-N"])
        layout.addRow("From:", self.src); layout.addRow("To:", self.tgt); layout.addRow("Type:", self.type)
        btn = QPushButton("Link"); btn.clicked.connect(self.accept); layout.addRow(btn)
    def get_data(self): return self.src.currentText(), self.tgt.currentText(), self.type.currentText()

class TableEditorDialog(QDialog):
    def __init__(self, table_name, columns):
        super().__init__(); self.setWindowTitle(f"Edit {table_name}"); self.resize(400, 300); self.layout = QVBoxLayout(self)
        self.name_edit = QLineEdit(table_name); self.layout.addWidget(QLabel("Name:")); self.layout.addWidget(self.name_edit)
        self.col_list = QListWidget(); 
        for col in columns: self.col_list.addItem(f"{col.name} ({col.data_type})")
        self.layout.addWidget(self.col_list)
        h = QHBoxLayout(); self.n_col = QLineEdit(); self.n_type = QComboBox(); self.n_type.addItems(["VARCHAR", "INTEGER", "TEXT", "DATE"])
        btn = QPushButton("+"); btn.clicked.connect(self.add_c); h.addWidget(self.n_col); h.addWidget(self.n_type); h.addWidget(btn); self.layout.addLayout(h)
        b_del = QPushButton("Delete Col"); b_del.clicked.connect(self.del_c); self.layout.addWidget(b_del)
        save = QPushButton("Save"); save.clicked.connect(self.accept); self.layout.addWidget(save)
        self.added_cols = []; self.deleted_cols = []
    def add_c(self): 
        if self.n_col.text(): self.added_cols.append((self.n_col.text(), self.n_type.currentText())); self.col_list.addItem(f"{self.n_col.text()}"); self.n_col.clear()
    def del_c(self): 
        if self.col_list.currentItem(): self.deleted_cols.append(self.col_list.currentItem().text().split(" ")[0]); self.col_list.takeItem(self.col_list.currentRow())

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ultimate DB Designer v7.0 (Project Manager)") 
        self.resize(1300, 850); self.setStyleSheet(DARK_THEME)
        self.comms = Communicate()

        # --- MENU BAR ---
        menu_bar = self.menuBar()
        file_menu = menu_bar.addMenu("File")
        
        self.act_new = QAction("New Project", self); self.act_new.setShortcut(QKeySequence.New)
        self.act_open = QAction("Open Project...", self); self.act_open.setShortcut(QKeySequence.Open)
        self.act_save = QAction("Save Project As...", self); self.act_save.setShortcut(QKeySequence.Save)
        self.act_exit = QAction("Exit", self)
        self.act_exit.triggered.connect(self.close)

        file_menu.addAction(self.act_new)
        file_menu.addAction(self.act_open)
        file_menu.addAction(self.act_save)
        file_menu.addSeparator()
        file_menu.addAction(self.act_exit)

        central = QWidget(); self.setCentralWidget(central); main_layout = QHBoxLayout(central)
        
        tools = QVBoxLayout()
        self.btn_toggle_toolbox = QPushButton("🎨 Visual Mode"); self.btn_toggle_toolbox.setCheckable(True); self.btn_toggle_toolbox.clicked.connect(self.toggle_toolbox)
        
        self.btn_add_table = QPushButton("➕ Table"); self.btn_add_rel = QPushButton("🔗 Connect"); self.btn_gen_sql = QPushButton("📄 SQL Code"); self.btn_exec_sql = QPushButton("▶ Run SQL")
        tools.addWidget(QLabel("DESIGNER")); tools.addWidget(self.btn_toggle_toolbox); tools.addWidget(self.btn_add_table); tools.addWidget(self.btn_add_rel)
        tools.addSpacing(20); tools.addWidget(QLabel("ENGINE")); tools.addWidget(self.btn_gen_sql); tools.addWidget(self.btn_exec_sql); tools.addStretch()

        self.toolbox = ToolboxWidget(); self.toolbox.setVisible(False)
        self.canvas = SchemaCanvas(self.comms)
        
        right = QWidget(); r_layout = QVBoxLayout(right)
        self.sql_display = QTextEdit(); self.result_table = QTableWidget()
        r_layout.addWidget(QLabel("SQL:")); r_layout.addWidget(self.sql_display); r_layout.addWidget(QLabel("Result:")); r_layout.addWidget(self.result_table)

        splitter = QSplitter(Qt.Horizontal); w = QWidget(); w.setLayout(tools)
        splitter.addWidget(w); splitter.addWidget(self.toolbox); splitter.addWidget(self.canvas); splitter.addWidget(right)
        splitter.setStretchFactor(2, 4); main_layout.addWidget(splitter)

    def toggle_toolbox(self):
        v = self.btn_toggle_toolbox.isChecked(); self.toolbox.setVisible(v)
        if v: self.toolbox.setMaximumWidth(150)
    def display_results(self, columns, rows):
        self.result_table.clear(); self.result_table.setColumnCount(len(columns)); self.result_table.setHorizontalHeaderLabels(columns); self.result_table.setRowCount(len(rows))
        self.result_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        for r, row in enumerate(rows):
            for c, data in enumerate(row): self.result_table.setItem(r, c, QTableWidgetItem(str(data)))
"""
with open("views/main_window.py", "w", encoding="utf-8") as f: f.write(window_code)

# ---------------------------------------------------------
# 3. CONTROLLER: main_controller.py (تنفيذ الحفظ والفتح)
# ---------------------------------------------------------
ctrl_code = """from views.main_window import TableEditorDialog, RelationshipDialog, TableCreationDialog, DataEntryDialog
from PySide6.QtWidgets import QMessageBox, QFileDialog
import json

class MainController:
    def __init__(self, model, view):
        self.model = model; self.view = view
        
        # --- File Actions ---
        self.view.act_new.triggered.connect(self.new_project)
        self.view.act_save.triggered.connect(self.save_project)
        self.view.act_open.triggered.connect(self.open_project)

        # --- Buttons ---
        self.view.btn_add_table.clicked.connect(self.add_table)
        self.view.btn_add_rel.clicked.connect(self.open_relationship_dialog)
        self.view.btn_gen_sql.clicked.connect(self.generate_sql)
        self.view.btn_exec_sql.clicked.connect(self.execute_sql)
        
        # --- Comms ---
        self.view.comms.request_edit_table.connect(self.open_edit_table_dialog)
        self.view.comms.request_delete_table.connect(self.delete_table)
        self.view.comms.request_delete_rel.connect(self.delete_relationship)
        self.view.comms.request_insert_data.connect(self.open_insert_data_dialog)
        self.view.comms.request_create_table_at.connect(self.create_table_at_drop)

    def new_project(self):
        reply = QMessageBox.question(self.view, 'New Project', "Are you sure? Unsaved changes will be lost.", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.model.clear()
            self.view.canvas.scene.clear()
            self.view.canvas.table_items = {}
            self.view.canvas.connector_items = []
            self.view.sql_display.clear()
            self.view.result_table.clear()

    def save_project(self):
        file_path, _ = QFileDialog.getSaveFileName(self.view, "Save Project", "", "JSON Files (*.json)")
        if file_path:
            try:
                data = self.model.to_dict()
                with open(file_path, 'w') as f:
                    json.dump(data, f, indent=4)
                QMessageBox.information(self.view, "Success", "Project saved successfully!")
            except Exception as e:
                QMessageBox.critical(self.view, "Error", f"Could not save project: {e}")

    def open_project(self):
        file_path, _ = QFileDialog.getOpenFileName(self.view, "Open Project", "", "JSON Files (*.json)")
        if file_path:
            try:
                # 1. Load Data
                with open(file_path, 'r') as f:
                    data = json.load(f)
                
                # 2. Update Model
                self.model.from_dict(data)
                
                # 3. Update View (Redraw everything)
                self.view.canvas.scene.clear()
                self.view.canvas.table_items = {}
                self.view.canvas.connector_items = []
                
                # Redraw tables
                for table in self.model.tables.values():
                    self.view.canvas.add_table_visual(table.name, table.x, table.y)
                    self.view.canvas.update_table_visual(table.name, table.columns)
                
                # Redraw relationships
                for rel in self.model.relationships:
                    self.view.canvas.add_connector(rel.from_table, rel.to_table, rel.rel_type)

                QMessageBox.information(self.view, "Success", "Project loaded successfully!")
            except Exception as e:
                QMessageBox.critical(self.view, "Error", f"Could not load project: {e}")

    def create_table_at_drop(self, x, y):
        dialog = TableCreationDialog()
        if dialog.exec():
            name, pk, pkt = dialog.get_data()
            if name: 
                try: 
                    self.model.add_table(name, pk, pkt, x, y)
                    self.view.canvas.add_table_visual(name, x, y)
                    self.view.canvas.update_table_visual(name, self.model.tables[name].columns)
                except Exception as e: QMessageBox.critical(self.view, "Error", str(e))

    def add_table(self):
        dialog = TableCreationDialog()
        if dialog.exec():
            name, pk, pkt = dialog.get_data()
            if name:
                try:
                    self.model.add_table(name, pk, pkt, 100, 100)
                    self.view.canvas.add_table_visual(name, 100, 100)
                    self.view.canvas.update_table_visual(name, self.model.tables[name].columns)
                except Exception as e: QMessageBox.critical(self.view, "Error", str(e))

    def open_relationship_dialog(self):
        tables = list(self.model.tables.keys())
        if len(tables) < 2: QMessageBox.warning(self.view, "Warning", "Need 2 tables!"); return
        dialog = RelationshipDialog(tables)
        if dialog.exec():
            src, tgt, rtype = dialog.get_data()
            if src == tgt: return
            if rtype == "N-N":
                mid = f"{src}_{tgt}"
                if mid in self.model.tables: mid = f"{tgt}_{src}"
                if mid in self.model.tables: return
                try:
                    s_item, t_item = self.view.canvas.table_items[src], self.view.canvas.table_items[tgt]
                    mx, my = (s_item.x()+t_item.x())/2, (s_item.y()+t_item.y())/2 + 50
                    self.model.add_table(mid, "id", "INTEGER", mx, my)
                    self.view.canvas.add_table_visual(mid, mx, my)
                    self.model.add_column(mid, f"{src}_id", "INTEGER"); self.model.add_column(mid, f"{tgt}_id", "INTEGER")
                    self.view.canvas.update_table_visual(mid, self.model.tables[mid].columns)
                    self.model.add_relationship(mid, src, "1-N"); self.view.canvas.add_connector(mid, src, "1-N")
                    self.model.add_relationship(mid, tgt, "1-N"); self.view.canvas.add_connector(mid, tgt, "1-N")
                except: pass
            else:
                self.model.add_relationship(src, tgt, rtype)
                self.view.canvas.add_connector(src, tgt, rtype)
                self.view.canvas.update_table_visual(src, self.model.tables[src].columns)

    def delete_relationship(self, f, t):
        self.model.delete_relationship(f, t); self.view.canvas.remove_connector_visual(f, t)
        self.view.canvas.update_table_visual(f, self.model.tables[f].columns)
        if "_" in f and t in f: self.delete_table(f)

    def open_edit_table_dialog(self, name):
        if name not in self.model.tables: return
        dialog = TableEditorDialog(name, self.model.tables[name].columns)
        if dialog.exec():
            new_name = dialog.name_edit.text()
            if new_name != name:
                try: self.model.rename_table(name, new_name); self.view.canvas.rename_table_visual(name, new_name); name = new_name
                except: pass
            for c, t in dialog.added_cols: self.model.add_column(name, c, t)
            for c in dialog.deleted_cols: self.model.delete_column(name, c)
            self.view.canvas.update_table_visual(name, self.model.tables[name].columns)

    def open_insert_data_dialog(self, name):
        dialog = DataEntryDialog(name, self.model.tables[name].columns)
        if dialog.exec():
            v = dialog.get_values(); c = ", ".join(v.keys()); val = ", ".join([f"'{x}'" for x in v.values()])
            msg, res = self.model.execute_query(f"INSERT INTO {name} ({c}) VALUES ({val});")
            if msg[0] == "Error": QMessageBox.critical(self.view, "Error", str(res[0]))
            else: QMessageBox.information(self.view, "Success", "Done!")

    def delete_table(self, name):
        self.model.delete_table(name); self.view.canvas.remove_table_visual(name)

    def generate_sql(self): self.view.sql_display.setText(self.model.generate_sql())

    def execute_sql(self):
        q = self.view.sql_display.toPlainText().strip(); 
        if not q: return
        if q.upper().startswith("CREATE TABLE"):
            try: 
                nm = self.model.parse_create_table_sql(q)
                if nm: self.view.canvas.add_table_visual(nm, 50, 50); self.view.canvas.update_table_visual(nm, self.model.tables[nm].columns)
            except: pass
        c, r = self.model.execute_query(q)
        self.view.display_results(c, r)
"""
with open("controllers/main_controller.py", "w", encoding="utf-8") as f: f.write(ctrl_code)

print("✅ تم التحديث إلى الإصدار v7.0 (Project Manager)!")
print("💾 الآن يمكنك حفظ وفتح المشاريع.")
print("👉 شغل البرنامج: python main.py")