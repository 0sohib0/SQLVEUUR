from views.main_window import TableEditorDialog, RelationshipDialog, TableCreationDialog, DataEntryDialog
from PySide6.QtWidgets import QMessageBox

class MainController:
    def __init__(self, model, view):
        self.model = model
        self.view = view

        self.view.btn_add_table.clicked.connect(self.add_table)
        self.view.btn_add_rel.clicked.connect(self.open_relationship_dialog)
        self.view.btn_gen_sql.clicked.connect(self.generate_sql)
        self.view.btn_exec_sql.clicked.connect(self.execute_sql)

        self.view.comms.request_edit_table.connect(self.open_edit_table_dialog)
        self.view.comms.request_delete_table.connect(self.delete_table)
        self.view.comms.request_delete_rel.connect(self.delete_relationship)
        self.view.comms.request_insert_data.connect(self.open_insert_data_dialog) # NEW

    def add_table(self):
        dialog = TableCreationDialog()
        if dialog.exec():
            name, pk_name, pk_type = dialog.get_data()
            if not name: return
            try:
                self.model.add_table(name, pk_name, pk_type)
                self.view.canvas.add_table_visual(name)
                self.view.canvas.update_table_visual(name, self.model.tables[name].columns)
            except Exception as e: QMessageBox.critical(self.view, "Error", str(e))

    def open_relationship_dialog(self):
        tables = list(self.model.tables.keys())
        if len(tables) < 2: QMessageBox.warning(self.view, "Warning", "Need 2 tables!"); return
        dialog = RelationshipDialog(tables)
        if dialog.exec():
            src, tgt, rtype = dialog.get_data()
            if src == tgt: return
            if rtype == "N-N":
                mid_name = f"{src}_{tgt}"
                if mid_name in self.model.tables: mid_name = f"{tgt}_{src}"
                if mid_name in self.model.tables: return
                try:
                    src_item, tgt_item = self.view.canvas.table_items[src], self.view.canvas.table_items[tgt]
                    self.model.add_table(mid_name, "id", "INTEGER", (src_item.x()+tgt_item.x())/2, (src_item.y()+tgt_item.y())/2 + 50)
                    self.view.canvas.add_table_visual(mid_name, (src_item.x()+tgt_item.x())/2, (src_item.y()+tgt_item.y())/2 + 50)
                    self.model.add_column(mid_name, f"{src}_id", "INTEGER"); self.model.add_column(mid_name, f"{tgt}_id", "INTEGER")
                    self.view.canvas.update_table_visual(mid_name, self.model.tables[mid_name].columns)
                    self.model.add_relationship(mid_name, src, "1-N"); self.view.canvas.add_connector(mid_name, src, "1-N")
                    self.model.add_relationship(mid_name, tgt, "1-N"); self.view.canvas.add_connector(mid_name, tgt, "1-N")
                except: pass
            else:
                self.model.add_relationship(src, tgt, rtype)
                self.view.canvas.add_connector(src, tgt, rtype)
                self.view.canvas.update_table_visual(src, self.model.tables[src].columns)

    def delete_relationship(self, from_name, to_name):
        self.model.delete_relationship(from_name, to_name)
        self.view.canvas.remove_connector_visual(from_name, to_name)
        self.view.canvas.update_table_visual(from_name, self.model.tables[from_name].columns)
        if "_" in from_name and to_name in from_name: self.delete_table(from_name)

    def open_edit_table_dialog(self, table_name):
        if table_name not in self.model.tables: return
        dialog = TableEditorDialog(table_name, self.model.tables[table_name].columns)
        if dialog.exec():
            new_name = dialog.name_edit.text()
            if new_name != table_name:
                try: self.model.rename_table(table_name, new_name); self.view.canvas.rename_table_visual(table_name, new_name); table_name = new_name
                except: pass
            for c, t in dialog.added_cols: self.model.add_column(table_name, c, t)
            for c in dialog.deleted_cols: self.model.delete_column(table_name, c)
            self.view.canvas.update_table_visual(table_name, self.model.tables[table_name].columns)

    # --- NEW: Data Entry Handler ---
    def open_insert_data_dialog(self, table_name):
        tbl = self.model.tables[table_name]
        # Only show non-PK columns usually, but for simplicity show all
        dialog = DataEntryDialog(table_name, tbl.columns)
        if dialog.exec():
            values = dialog.get_values()
            # Construct INSERT statement
            cols = ", ".join(values.keys())
            vals = ", ".join([f"'{v}'" for v in values.values()])
            query = f"INSERT INTO {table_name} ({cols}) VALUES ({vals});"
            
            # Execute silently
            msg, res = self.model.execute_query(query)
            if msg[0] == "Error": QMessageBox.critical(self.view, "Insert Error", str(res[0]))
            else: QMessageBox.information(self.view, "Success", "Data Inserted Successfully!")

    def delete_table(self, table_name):
        self.model.delete_table(table_name)
        self.view.canvas.remove_table_visual(table_name)

    def generate_sql(self):
        self.view.sql_display.setText(self.model.generate_sql())

    def execute_sql(self):
        query = self.view.sql_display.toPlainText().strip()
        if not query: return
        
        # --- NEW: Check if it's a CREATE TABLE to update visuals ---
        if query.upper().startswith("CREATE TABLE"):
            try:
                # Try parsing it
                new_tbl_name = self.model.parse_create_table_sql(query)
                if new_tbl_name:
                    self.view.canvas.add_table_visual(new_tbl_name, 50, 50)
                    self.view.canvas.update_table_visual(new_tbl_name, self.model.tables[new_tbl_name].columns)
            except Exception as e:
                pass # If parsing fails, just execute as normal SQL
        
        cols, rows = self.model.execute_query(query)
        self.view.display_results(cols, rows)
