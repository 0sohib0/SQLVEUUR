from views.main_window import TableEditorDialog, RelationshipDialog, TableCreationDialog, DataEntryDialog
from PySide6.QtWidgets import QMessageBox, QFileDialog
import json

class MainController:
    def __init__(self, model, view):
        self.model = model; self.view = view
        
        # --- File Actions ---
        self.view.act_new.triggered.connect(self.new_project)
        self.view.act_save.triggered.connect(self.save_project)
        self.view.act_open.triggered.connect(self.open_project)

        # --- Buttons ---
        self.view.btn_add_table.clicked.connect(self.add_table)
        self.view.btn_add_rel.clicked.connect(self.open_relationship_dialog)
        self.view.btn_gen_sql.clicked.connect(self.generate_sql)
        self.view.btn_exec_sql.clicked.connect(self.execute_sql)
        
        # --- Comms ---
        self.view.comms.request_edit_table.connect(self.open_edit_table_dialog)
        self.view.comms.request_delete_table.connect(self.delete_table)
        self.view.comms.request_delete_rel.connect(self.delete_relationship)
        self.view.comms.request_insert_data.connect(self.open_insert_data_dialog)
        self.view.comms.request_create_table_at.connect(self.create_table_at_drop)

    def new_project(self):
        reply = QMessageBox.question(self.view, 'New Project', "Are you sure? Unsaved changes will be lost.", QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.model.clear()
            self.view.canvas.scene.clear()
            self.view.canvas.table_items = {}
            self.view.canvas.connector_items = []
            self.view.sql_display.clear()
            self.view.result_table.clear()

    def save_project(self):
        file_path, _ = QFileDialog.getSaveFileName(self.view, "Save Project", "", "JSON Files (*.json)")
        if file_path:
            try:
                data = self.model.to_dict()
                with open(file_path, 'w') as f:
                    json.dump(data, f, indent=4)
                QMessageBox.information(self.view, "Success", "Project saved successfully!")
            except Exception as e:
                QMessageBox.critical(self.view, "Error", f"Could not save project: {e}")

    def open_project(self):
        file_path, _ = QFileDialog.getOpenFileName(self.view, "Open Project", "", "JSON Files (*.json)")
        if file_path:
            try:
                # 1. Load Data
                with open(file_path, 'r') as f:
                    data = json.load(f)
                
                # 2. Update Model
                self.model.from_dict(data)
                
                # 3. Update View (Redraw everything)
                self.view.canvas.scene.clear()
                self.view.canvas.table_items = {}
                self.view.canvas.connector_items = []
                
                # Redraw tables
                for table in self.model.tables.values():
                    self.view.canvas.add_table_visual(table.name, table.x, table.y)
                    self.view.canvas.update_table_visual(table.name, table.columns)
                
                # Redraw relationships
                for rel in self.model.relationships:
                    self.view.canvas.add_connector(rel.from_table, rel.to_table, rel.rel_type)

                QMessageBox.information(self.view, "Success", "Project loaded successfully!")
            except Exception as e:
                QMessageBox.critical(self.view, "Error", f"Could not load project: {e}")

    def create_table_at_drop(self, x, y):
        dialog = TableCreationDialog()
        if dialog.exec():
            name, pk, pkt = dialog.get_data()
            if name: 
                try: 
                    self.model.add_table(name, pk, pkt, x, y)
                    self.view.canvas.add_table_visual(name, x, y)
                    self.view.canvas.update_table_visual(name, self.model.tables[name].columns)
                except Exception as e: QMessageBox.critical(self.view, "Error", str(e))

    def add_table(self):
        dialog = TableCreationDialog()
        if dialog.exec():
            name, pk, pkt = dialog.get_data()
            if name:
                try:
                    self.model.add_table(name, pk, pkt, 100, 100)
                    self.view.canvas.add_table_visual(name, 100, 100)
                    self.view.canvas.update_table_visual(name, self.model.tables[name].columns)
                except Exception as e: QMessageBox.critical(self.view, "Error", str(e))

    def open_relationship_dialog(self):
        tables = list(self.model.tables.keys())
        if len(tables) < 2: QMessageBox.warning(self.view, "Warning", "Need 2 tables!"); return
        dialog = RelationshipDialog(tables)
        if dialog.exec():
            src, tgt, rtype = dialog.get_data()
            if src == tgt: return
            if rtype == "N-N":
                mid = f"{src}_{tgt}"
                if mid in self.model.tables: mid = f"{tgt}_{src}"
                if mid in self.model.tables: return
                try:
                    s_item, t_item = self.view.canvas.table_items[src], self.view.canvas.table_items[tgt]
                    mx, my = (s_item.x()+t_item.x())/2, (s_item.y()+t_item.y())/2 + 50
                    self.model.add_table(mid, "id", "INTEGER", mx, my)
                    self.view.canvas.add_table_visual(mid, mx, my)
                    self.model.add_column(mid, f"{src}_id", "INTEGER"); self.model.add_column(mid, f"{tgt}_id", "INTEGER")
                    self.view.canvas.update_table_visual(mid, self.model.tables[mid].columns)
                    self.model.add_relationship(mid, src, "1-N"); self.view.canvas.add_connector(mid, src, "1-N")
                    self.model.add_relationship(mid, tgt, "1-N"); self.view.canvas.add_connector(mid, tgt, "1-N")
                except: pass
            else:
                self.model.add_relationship(src, tgt, rtype)
                self.view.canvas.add_connector(src, tgt, rtype)
                self.view.canvas.update_table_visual(src, self.model.tables[src].columns)

    def delete_relationship(self, f, t):
        self.model.delete_relationship(f, t); self.view.canvas.remove_connector_visual(f, t)
        self.view.canvas.update_table_visual(f, self.model.tables[f].columns)
        if "_" in f and t in f: self.delete_table(f)

    def open_edit_table_dialog(self, name):
        if name not in self.model.tables: return
        dialog = TableEditorDialog(name, self.model.tables[name].columns)
        if dialog.exec():
            new_name = dialog.name_edit.text()
            if new_name != name:
                try: self.model.rename_table(name, new_name); self.view.canvas.rename_table_visual(name, new_name); name = new_name
                except: pass
            for c, t in dialog.added_cols: self.model.add_column(name, c, t)
            for c in dialog.deleted_cols: self.model.delete_column(name, c)
            self.view.canvas.update_table_visual(name, self.model.tables[name].columns)

    def open_insert_data_dialog(self, name):
        dialog = DataEntryDialog(name, self.model.tables[name].columns)
        if dialog.exec():
            v = dialog.get_values(); c = ", ".join(v.keys()); val = ", ".join([f"'{x}'" for x in v.values()])
            msg, res = self.model.execute_query(f"INSERT INTO {name} ({c}) VALUES ({val});")
            if msg[0] == "Error": QMessageBox.critical(self.view, "Error", str(res[0]))
            else: QMessageBox.information(self.view, "Success", "Done!")

    def delete_table(self, name):
        self.model.delete_table(name); self.view.canvas.remove_table_visual(name)

    def generate_sql(self): self.view.sql_display.setText(self.model.generate_sql())

    def execute_sql(self):
        q = self.view.sql_display.toPlainText().strip(); 
        if not q: return
        if q.upper().startswith("CREATE TABLE"):
            try: 
                nm = self.model.parse_create_table_sql(q)
                if nm: self.view.canvas.add_table_visual(nm, 50, 50); self.view.canvas.update_table_visual(nm, self.model.tables[nm].columns)
            except: pass
        c, r = self.model.execute_query(q)
        self.view.display_results(c, r)
